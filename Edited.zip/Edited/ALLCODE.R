# Load the required packages
my_libraries <- c("tidyverse", "skimr", "sf", "readxl", "kableExtra", "vegclust",
                  "lubridate", "janitor", "caper", "RCurl", "XML", "dplyr", "reshape", "writexl", 
                  "adespatial", "vegan", "SoDA", "kableExtra", "fuzzySim", "dendextend", "MVPARTwrap", 
                  "mvpart", "pvclust", "gclus", "cluster", "ade4", "labdsv", "data.table")


sapply(my_libraries, library, character.only = TRUE)

source("final/functions/drawmap_stefedit.R") #--> see edit
#source("drawmap3.R")
#source("hcoplot.R") 
#source("test.a.R")
#source("coldiss.R")
#source("bartlett.perm.R")
#source("boxplerk.R")
#source("boxplert.R")
#source("final/functions/triplot.rda.R")
#source("final/functions/plot.lda.R")
#source("final/functions/polyvars.R")
#source("final/functions/screestick.R")

#====================================================================================================
#DATA PREP
tongu_data <- read_excel("tongu_data.xlsx", 
                         sheet = "tongu", col_types = c("date", "skip", "skip", "numeric", "numeric", 
                                                        "numeric", "text", "text", "numeric", 
                                                        "text", "text", "numeric", "numeric", 
                                                        "text", "numeric", "numeric", "numeric", 
                                                        "numeric", "text", "text", "text", 
                                                        "text", "text", "numeric", "numeric", 
                                                        "numeric", "numeric", "numeric", 
                                                        "numeric", "numeric"))
#using library(janitor) and library(fuzzySim)
tonga<-tongu_data %>% clean_names(.,case ="snake")
tonga<-tongu_data
specieslist<-(as.data.frame(unique(tonga$species)))
tonga$species<-spCodes(tonga$species, nchar.gen = 3, nchar.sp = 9, nchar.ssp = 0,
                       sep.species = " ", sep.spcode = ".", verbosity = 2)
specieslist<- cbind(specieslist, (unique(tonga$species)))
#decided not to do this. 
#tonga<-tonga%>% group_by(species) %>% filter(n()>= 5) %>% ungroup() 
sitelist<-(as.data.frame(unique(tonga$site)))
tonga$site<-abbreviate(tonga$site)
sitelist<- cbind(sitelist, (unique(tonga$site)))

# Save multiple objects
save(tongu_data, tonga, sitelist, specieslist, file = "Tonga.RData")
# To load the data again
load("Tonga.RData")

#=== === === === === === === === === === === === === === === 
##EXPLORING COMMUNITY MATRIX Y 
#To skip exploration, go to line 361
#sum transects per site
#density is best
#chord transformation is best
#=================================================================================================
#Cast data using library(reshape) abundance, density, biomass -->make sure library(reshape) not library(reshape2)
#Abundance
tonga.a<-cast(tonga, formula = site~species, sum, value = "abundance", fill = 0) #abundance
tonga.a<-column_to_rownames(tonga.a, var ="site")

#raw abundance data pca
tonga.a.pca<-rda(tonga.a, scale =TRUE)
summary(tonga.a.pca)
screeplot(tonga.a.pca, bstick=TRUE)  
plot(tonga.a.pca, scaling = 1)

#hellinger
tonga.ah <- decostand(tonga.a, method="hellinger") 
tonga.ah.pca <- rda(tonga.ah)
summary(tonga.ah.pca)
screeplot(tonga.ah.pca, bstick=TRUE)  
plot(tonga.ah.pca, scaling = 1)

#chord using library(vegan)
tonga.ac <- decostand(tonga.a, "nor")
tonga.ac.d <- dist(tonga.ac)
tonga.ac.pca <- rda(tonga.ac)
summary(tonga.ac.pca)
screeplot(tonga.ac.pca, bstick=TRUE)  
plot(tonga.ac.pca, scaling = 1)

#log-chord
tonga.aln <- log1p(tonga.a)
tonga.alogc <- decostand(tonga.aln, "nor")
tonga.alogc.d <- dist(tonga.alogc)
tonga.alogc.pca <- rda(tonga.alogc)
summary(tonga.alogc.pca)
screeplot(tonga.alogc.pca, bstick=TRUE)  
plot(tonga.alogc.pca, scaling = 1)

#box-cox-chord with custom exponent 
box.cox.chord <- 
  function(mat, 
           bc.exp=0.1) { #test with varying exponents (note: bc.exp = 0.5 is the same as hellinger transform)
    # Internal function
    vec.norm <- function(vec)  sqrt(sum(vec^2))
    #
    chck <- apply(mat, 1, sum)
    if(any(chck == 0)) stop("Rows",which(chck==0)," of the data matrix sum to 0")
    #
    # Apply the user-selected Box-Cox exponent (bc.exp) to the frequency data
    if(bc.exp==0) {
      tmp <- log(mat+1) 
    } else { 
      tmp <- mat^bc.exp 
    }
    row.norms <- apply(tmp, 1, vec.norm)
    #
    # Apply the chord transformation to matrix "tmp" before returning it
    res <- sweep(tmp, 1, row.norms, "/")
  }

tonga.abox<-box.cox.chord(tonga.a)
tonga.abox.pca <- rda(tonga.abox)
summary(tonga.abox.pca)
screeplot(tonga.abox.pca, bstick=TRUE)  
plot(tonga.abox.pca, scaling = 1)

###Density per 1000m^2
tonga.dkm<-cast(tonga, formula = site~species, sum, value = "density1000", fill = 0)
tonga.dkm<-column_to_rownames(tonga.dkm, var = "site")

tonga.dkmh <- decostand(tonga.dkm, method="hellinger") 
tonga.dkmh.pca <- rda(tonga.dkmh)
summary(tonga.dkmh.pca)
screeplot(tonga.dkmh.pca, bstick=TRUE)  
plot(tonga.dkmh.pca, scaling = 1)

#chord using library(vegan)
tonga.dkmc <- decostand(tonga.dkm, "nor")
tonga.dkmc.d <- dist(tonga.dkmc)
tonga.dkmc.pca <- rda(tonga.dkmc)
summary(tonga.dkmc.pca)
screeplot(tonga.dkmc.pca, bstick=TRUE)  
plot(tonga.dkmc.pca, scaling = 1)

#log-chord
tonga.dkmln <- log1p(tonga.dkm)
tonga.dkmlogc <- decostand(tonga.dkmln, "nor")
tonga.dkmlogc.d <- dist(tonga.dkmlogc)
tonga.dkmlogc.pca <- rda(tonga.dkmlogc)
summary(tonga.dkmlogc.pca)
screeplot(tonga.dkmlogc.pca, bstick=TRUE)  
plot(tonga.dkmlogc.pca, scaling = 1)

#box-cox-chord with custom exponent 
box.cox.chord <- 
  function(mat, 
           bc.exp=0.1) { #test with varying exponents (note: bc.exp = 0.5 is the same as hellinger transform)
    # Internal function
    vec.norm <- function(vec)  sqrt(sum(vec^2))
    #
    chck <- apply(mat, 1, sum)
    if(any(chck == 0)) stop("Rows",which(chck==0)," of the data matrix sum to 0")
    #
    # Apply the user-selected Box-Cox exponent (bc.exp) to the frequency data
    if(bc.exp==0) {
      tmp <- log(mat+1) 
    } else { 
      tmp <- mat^bc.exp 
    }
    row.norms <- apply(tmp, 1, vec.norm)
    #
    # Apply the chord transformation to matrix "tmp" before returning it
    res <- sweep(tmp, 1, row.norms, "/")
  }

tonga.dkmbox<-box.cox.chord(tonga.dkm)
tonga.dkmbox.pca <- rda(tonga.dkmbox)
summary(tonga.dkmbox.pca)
screeplot(tonga.dkmbox.pca, bstick=TRUE)  
plot(tonga.dkmbox.pca, scaling = 1)

###Density per m^2
tonga.d<-cast(tonga, formula = site~species, sum, value = "density", fill = 0) #
tonga.d<-column_to_rownames(tonga.d, var = "site")

tonga.dh <- decostand(tonga.d, method="hellinger") 
tonga.dh.pca <- rda(tonga.dh)
summary(tonga.dh.pca)
screeplot(tonga.dh.pca, bstick=TRUE)  
plot(tonga.dh.pca, scaling = 1)

#chord using library(vegan)
tonga.dc <- decostand(tonga.d, "nor")
tonga.dc.d <- dist(tonga.dc)
tonga.dc.pca <- rda(tonga.dc)
summary(tonga.dc.pca)
screeplot(tonga.dc.pca, bstick=TRUE)  
plot(tonga.dc.pca, scaling = 1)
View(tonga.dc)

#log-chord
tonga.dln <- log1p(tonga.d)
tonga.dlogc <- decostand(tonga.dln, "nor")
tonga.dlogc.d <- dist(tonga.dlogc)
tonga.dlogc.pca <- rda(tonga.dlogc)
summary(tonga.dlogc.pca)
screeplot(tonga.dlogc.pca, bstick=TRUE)  
plot(tonga.dlogc.pca, scaling = 1)

#box-cox-chord with custom exponent 
box.cox.chord <- 
  function(mat, 
           bc.exp=0.1) { #test with varying exponents (note: bc.exp = 0.5 is the same as hellinger transform)
    # Internal function
    vec.norm <- function(vec)  sqrt(sum(vec^2))
    #
    chck <- apply(mat, 1, sum)
    if(any(chck == 0)) stop("Rows",which(chck==0)," of the data matrix sum to 0")
    #
    # Apply the user-selected Box-Cox exponent (bc.exp) to the frequency data
    if(bc.exp==0) {
      tmp <- log(mat+1) 
    } else { 
      tmp <- mat^bc.exp 
    }
    row.norms <- apply(tmp, 1, vec.norm)
    #
    # Apply the chord transformation to matrix "tmp" before returning it
    res <- sweep(tmp, 1, row.norms, "/")
  }

tonga.dbox<-box.cox.chord(tonga.d)
tonga.dbox.pca <- rda(tonga.dbox)
summary(tonga.dbox.pca)
screeplot(tonga.dbox.pca, bstick=TRUE)  
plot(tonga.dbox.pca, scaling = 1)

###Biomass kg
tonga.b<-cast(tonga, formula = site~species, sum, value  = "biomass_kg", fill = 0) #biomass
tonga.b<-column_to_rownames(tonga.b, var ="site")

tonga.bh <- decostand(tonga.b, method="hellinger") 
tonga.bh.pca <- rda(tonga.bh)
summary(tonga.bh.pca)
screeplot(tonga.bh.pca, bstick=TRUE)  
plot(tonga.bh.pca, scaling = 1)

#chord using library(vegan)
tonga.bc <- decostand(tonga.b, "nor")
tonga.bc.d <- dist(tonga.bc)
tonga.bc.pca <- rda(tonga.bc)
summary(tonga.bc.pca)
screeplot(tonga.bc.pca, bstick=TRUE)  
plot(tonga.bpca, scaling = 1)

#log-chord
tonga.bln <- log1p(tonga.b)
tonga.blogc <- decostand(tonga.bln, "nor")
tonga.blogc.d <- dist(tonga.blogc)
tonga.blogc.pca <- rda(tonga.blogc)
summary(tonga.blogc.pca)
screeplot(tonga.blogc.pca, bstick=TRUE)  
plot(tonga.blogc.pca, scaling = 1)

#box-cox-chord with custom exponent 
box.cox.chord <- 
  function(mat, 
           bc.exp=0.1) { #test with varying exponents (note: bc.exp = 0.5 is the same as hellinger transform)
    # Internal function
    vec.norm <- function(vec)  sqrt(sum(vec^2))
    #
    chck <- apply(mat, 1, sum)
    if(any(chck == 0)) stop("Rows",which(chck==0)," of the data matrix sum to 0")
    #
    # Apply the user-selected Box-Cox exponent (bc.exp) to the frequency data
    if(bc.exp==0) {
      tmp <- log(mat+1) 
    } else { 
      tmp <- mat^bc.exp 
    }
    row.norms <- apply(tmp, 1, vec.norm)
    #
    # Apply the chord transformation to matrix "tmp" before returning it
    res <- sweep(tmp, 1, row.norms, "/")
  }

tonga.bbox<-box.cox.chord(tonga.b)
tonga.bbox.pca <- rda(tonga.bbox)
summary(tonga.bbox.pca)
screeplot(tonga.bbox.pca, bstick=TRUE)  
plot(tonga.bbox.pca, scaling = 1)

###Biomass kg/km
tonga.bkm<-cast(tonga, formula = site~species, sum, value  = "biomass_1000mkg", fill = 0) #biomass
tonga.bkm<-column_to_rownames(tonga.bkm, var ="site")

tonga.bkmh <- decostand(tonga.bkm, method="hellinger") 
tonga.bkmh.pca <- rda(tonga.bkmh)
summary(tonga.bkmh.pca)
screeplot(tonga.bkmh.pca, bstick=TRUE)  
plot(tonga.bkmh.pca, scaling = 1)

#chord using library(vegan)
tonga.bkmc <- decostand(tonga.bkm, "nor")
tonga.bkmc.d <- dist(tonga.bkmc)
tonga.bkmc.pca <- rda(tonga.bkmc)
summary(tonga.bkmc.pca)
screeplot(tonga.bkmc.pca, bstick=TRUE)  
plot(tonga.bkmc.pca, scaling = 1)

#log-chord
tonga.bkmln <- log1p(tonga.bkm)
tonga.bkmlogc <- decostand(tonga.bkmln, "nor")
tonga.bkmlogc.d <- dist(tonga.bkmlogc)
tonga.bkmlogc.pca <- rda(tonga.bkmlogc)
summary(tonga.bkmlogc.pca)
screeplot(tonga.bkmlogc.pca, bstick=TRUE)  
plot(tonga.bkmlogc.pca, scaling = 1)

#box-cox-chord with custom exponent 
box.cox.chord <- 
  function(mat, 
           bc.exp=0.1) { #test with varying exponents (note: bc.exp = 0.5 is the same as hellinger transform)
    # Internal function
    vec.norm <- function(vec)  sqrt(sum(vec^2))
    #
    chck <- apply(mat, 1, sum)
    if(any(chck == 0)) stop("Rows",which(chck==0)," of the data matrix sum to 0")
    #
    # Apply the user-selected Box-Cox exponent (bc.exp) to the frequency data
    if(bc.exp==0) {
      tmp <- log(mat+1) 
    } else { 
      tmp <- mat^bc.exp 
    }
    row.norms <- apply(tmp, 1, vec.norm)
    #
    # Apply the chord transformation to matrix "tmp" before returning it
    res <- sweep(tmp, 1, row.norms, "/")
  }

tonga.bkmbox<-box.cox.chord(tonga.bkm)
tonga.bkmbox.pca <- rda(tonga.bkmbox)
summary(tonga.bkmbox.pca)
screeplot(tonga.bkmbox.pca, bstick=TRUE)  
plot(tonga.bkmbox.pca, scaling = 1)
#####################################################################################################
#Multivariate Analyses on Community Data

#Raw Abundance 
tonga.a<-cast(tonga, formula = site~species, sum, value = "abundance", fill = 0) #abundance
tonga.a<-column_to_rownames(tonga.a, var ="site")

#Density per km
tonga.d<-cast(tonga, formula = site~species, sum, value = "density", fill = 0) #
tonga.d<-column_to_rownames(tonga.d, var = "site")

#chord using library(vegan)
tonga.dc <- decostand(tonga.d, "nor")
tonga.dc.d <- dist(tonga.dc)
tonga.dc.pca <- rda(tonga.dc)
summary(tonga.dc.pca)
screeplot(tonga.dc.pca, bstick=TRUE)  

#Biomass kg/km
tonga.bkm<-cast(tonga, formula = site~species, sum, value  = "biomass_1000mkg", fill = 0) #biomass
tonga.bkm<-column_to_rownames(tonga.bkm, var ="site")

#chord using library(vegan)
tonga.bkmc <- decostand(tonga.bkm, "nor")
tonga.bkmc.d <- dist(tonga.bkmc)
tonga.bkmc.pca <- rda(tonga.bkmc)
summary(tonga.bkmc.pca)
screeplot(tonga.bkmc.pca, bstick=TRUE)  

#abundance (chord) = 64.67 (with PC1 18.53, PC2 16.43 ==> 34.96)
#density (chord) = 68.24 (with PC1 18.75, PC2 17.21 ==> 35.96 (with PC3 48.73))
#biomass/km (chord) = 67.41 (with PC1 22.4, PC2 14.53 ==> 36.93 (with PC3 44.72))

#make nicer plots with cleanplot() function
source("final/functions/cleanplot.pca.R")
palette("default")
cleanplot.pca(tonga.dc.pca, scaling=2)
cleanplot.pca(tonga.dc.pca, scaling=1)
#we are interested in scaling 1, since we want to look at association between objects not species
#which species contribute most in the differences seen in sites, not correlation between species etc
species.R2 <- goodness(tonga.dc.pca, display="species", model="CA")
par(mfrow = c(1, 2))
cleanplot.pca(tonga.dc.pca, scaling = 1, select.spe = species.R2[,2] >= 0.4) # with 0.45 all species outside circle
cleanplot.pca(tonga.dc.pca, scaling = 1, ax2=3, select.spe = species.R2[,2] >= 0.4) 
##what are main species explaining variance (See specieslist for full names)
#Chrysiptera taupou (PC1 it seems)
#Amblyglyphidodon melanopterus
#Pomacentrus callainus
#Pomacentrus imitator
#Chromis margaritifer (not PC3)
#Chromis chrysura (not PC3)

#What if we look at consider the size/weight of the fish? with biomass per km 
species.R2 <- goodness(tonga.bkmc.pca, display="species", model="CA")
cleanplot.pca(tonga.bkmc.pca, scaling = 1, select.spe = species.R2[,2] >= 0.4) # with 0.45 all species outside circle
cleanplot.pca(tonga.bkmc.pca, scaling = 1, ax2=3, select.spe = species.R2[,2] >= 0.4) 
##we get different results --> large schools of small fish, vs.medium sch
#Scarus rivulatus (not with density)
#Scarus flavipectoralis (not with density, unless R>/= 0.3)
#Ctenochaetus striatus (not with density, unless R>/= 0.3)
#On axis 3 Amblyglyphidodon melanopterus

#If we take off rare species with:
#tonga<-tonga%>% group_by(species) %>% filter(n()>= 5) %>% ungroup()
#we get a slight decrease in overall variance explained, and not much changes in the species responsible for most variation
#looking at both PC1~PC2, and PC1~PC3
#we will use complete data set 
#If we look at abundances, without the correction for transect size, we see similar to density, with some resemblance to biomass/km
#In particular, we see scarus flavipectoralis, Yellowfin Parrotfish which has super high abundances, which are reduced when you 
#divide by 5 instead of 2, 
#PROBLEM
#The abundance and size of all large mobile fish were recorded to species level within a 5-m belt.
#All small, site-attached reef fish species were recorded along a 2-m belt.
#except species, such as the yellowfin parrotfish, range in size from lenghts of 3cm to 27cm 
#this likely includes juveniles, which have different behaviors and schooling patterns to adults (and are found in larger abundances)
#biomasses are also based on pre determined weight lenght relationships which can be tricky
#The length and abundance of reef fish were converted to biomass following published length–weight relationships for each species

######CLUSTERING##############
#library(unikn), colour blind friendly palette
n <- 10
h1 <- hcl.colors(n, palette = "Dynamic")
palette(h1)

## Hierarchical agglomerative clustering of the species abundance (density) data
# Attach site names to object of class 'dist'
attr(tonga.dc.d, "Labels") <- rownames(tonga.dc)

# Compute single linkage agglomerative clustering
tonga.single <- hclust(tonga.dc.d, method = "single")
# Compute complete-linkage agglomerative clustering
tonga.complete <- hclust(tonga.dc.d, method = "complete")
# Compute UPGMA agglomerative clustering
tonga.UPGMA <- hclust(tonga.dc.d, method = "average")
# Compute centroid clustering
tonga.centroid <- hclust(tonga.dc.d, method = "centroid")
# Compute Ward's minimum variance clustering
tonga.ward<- hclust(tonga.dc.d, method = "ward.D2")

## Plot a dendrogram using the default options
plot(tonga.single, 
     labels = rownames(tonga.d), 
     main = "Chord - Single linkage")
plot(tonga.complete, 
     labels = rownames(tonga.d), 
     main = "Chord - Complete linkage")
plot(tonga.UPGMA, 
     labels = rownames(tonga.d), 
     main = "Chord - UPGMA")
plot(tonga.centroid, 
     labels = rownames(tonga.d), 
     main = "Chord - Centroid")
plot(tonga.ward, 
     labels = rownames(tonga.dc), 
     main = "Chord - Ward")
# not very clear given the number of sites, better visualization needed

# Cophenetic correlations =========================================

# Single linkage clustering
tonga.single.coph <- cophenetic(tonga.single)
cor(tonga.dc.d, tonga.single.coph) #0.6347

# Complete linkage clustering
tonga.comp.coph <- cophenetic(tonga.complete)
cor(tonga.dc.d, tonga.comp.coph)#0.745

# Average clustering
tonga.UPGMA.coph <- cophenetic(tonga.UPGMA)
cor(tonga.dc.d, tonga.UPGMA.coph) #0.8241 ---------> best

# Ward clustering
tonga.ward.coph <- cophenetic(tonga.ward)
cor(tonga.dc.d, tonga.ward.coph) #0.72345

# Shepard-like diagrams
dev.new(
  title = "Cophenetic correlation",
  width = 8,
  height = 9,
  noRStudioGD = TRUE
)
par(mfrow = c(1, 1))
plot(
  tonga.dc.d,
  tonga.ward.coph,
  xlab = "Chord distance",
  ylab = "Cophenetic distance",
  asp = 1,
  xlim = c(0, sqrt(2)),
  ylim = c(0, max(tonga.ward$height)),
  main = c("Ward", paste("Cophenetic correlation =",
                         round(
                           cor(tonga.dc.d, tonga.ward.coph), 3
                         )))
)
abline(0, 1)
lines(lowess(tonga.dc.d, tonga.ward.coph), col = "red")
# Shepard-like diagrams comparing chord distances (species data) to cophenetic distances. 
#A LOWESS smoother shows the trend in each plot
#--> UPGMA looks best, Ward looks intersting, less scatter/ noise around points
#if we remove the sites with low observations, the plot doesnt change much, so the grouping we see isn't because of that
#some are very similar some are very different?

# Gower (1983) distance
(gow.dist.single <- sum((tonga.dc.d - tonga.single.coph) ^ 2)) # 315.3156
(gow.dist.comp <- sum((tonga.dc.d - tonga.comp.coph) ^ 2)) #  104.5889
(gow.dist.UPGMA <- sum((tonga.dc.d - tonga.UPGMA.coph) ^ 2)) # 30.69564 --> best again 
(gow.dist.ward <- sum((tonga.dc.d - tonga.ward.coph) ^ 2)) # 6431.152
#---> based on all of these tests, it seems like UPGMA agglomerative clustering is the best
##BUT
#Ward might be more interesting to us given the data, and the least squared method, so we will do both separately and compare 

# Graphs of fusion level values ===================================
dev.new(
  title = "Fusion levels",
  width = 12,
  height = 8,
  noRStudioGD = TRUE
)
par(mfrow = c(2, 2))
plot(
  tonga.complete$height,
  nrow(tonga.d):2,
  type = "S",
  main = "Fusion levels - Chord - Complete",
  ylab = "k (number of clusters)",
  xlab = "h (node height)",
  col = "grey"
)
text(tonga.complete$height,
     nrow(tonga.d):2,
     nrow(tonga.d):2,
     col = "red",
     cex = 0.8)
# Plot the fusion level values of the UPGMA clustering
plot(
  tonga.UPGMA$height,
  nrow(tonga.d):2,
  type = "S",
  main = "Fusion levels - Chord - UPGMA",
  ylab = "k (number of clusters)",
  xlab = "h (node height)",
  col = "grey"
)
text(tonga.UPGMA$height,
     nrow(tonga.d):2,
     nrow(tonga.d):2,
     col = "red",
     cex = 0.8)
# Plot the fusion level values of the Ward clustering
plot(
  tonga.ward$height,
  nrow(tonga.d):2,
  type = "S",
  main = "Fusion levels - Chord - Ward",
  ylab = "k (number of clusters)",
  xlab = "h (node height)",
  col = "grey"
)
text(tonga.ward$height,
     nrow(tonga.d):2,
     nrow(tonga.d):2,
     col = "red",
     cex = 0.8)
# Plot the fusion level values of the beta-flexible 
# clustering (-0.25)
plot(
  tonga.centroid$height,
  nrow(tonga.d):2,
  type = "S",
  main = "Fusion levels - Chord - Centroid",
  ylab = "k (number of clusters)",
  xlab = "h (node height)",
  col = "grey"
)
text(tonga.centroid$height,
     nrow(tonga.d):2,
     nrow(tonga.d):2,
     col = "red",
     cex = 0.8)
#this reaffirms are choice to look at ward 
### Graphs of the fusion level values seem to suggest 7 or 8 groups.


# Multiscale bootstrap resampling =================================
# Hierarchical clustering with p-values via multiscale bootstrap
# resampling

# Compute p-values for all clusters (edges) of the dendrogram
UPGMA.pv <- pvclust(t(tonga.dc),
                    method.hclust = "average",
                    method.dist = "euc",
                    parallel=TRUE)

# Plot dendrogram with p-values
dev.new(
  title = "Fish - Chord - p-values for UPGMA agglomerative clustering",
  width = 12,
  height = 8,
  noRStudioGD = TRUE
)
par(mfrow = c(1, 1))
plot(UPGMA.pv)
# Highlight clusters with high "au" p-values
pvrect(UPGMA.pv, alpha = 0.95, pv = "au")
lines(UPGMA.pv)
pvrect(UPGMA.pv, alpha = 0.91, border = 4)

###
ward.pv <- pvclust(t(tonga.dc),
                   method.hclust = "ward.D2",
                   method.dist = "euc",
                   parallel=TRUE)

# Plot dendrogram with p-values
dev.new(
  title = "Fish - Chord - p-values for Ward's minimum variance clustering",
  width = 12,
  height = 8,
  noRStudioGD = TRUE
)
par(mfrow = c(1, 1))
plot(ward.pv)
# Highlight clusters with high "au" p-values
pvrect(ward.pv, alpha = 0.95, pv = "au")
lines(ward.pv)
pvrect(ward.pv, alpha = 0.91, border = 4)

# "This function plots a dendrogram with p-values for given object
# of class pvclust. AU p-value (printed in red color in default) 
# is the abbreviation of "approximately unbiased" p-value, which is 
# calculated by multiscale bootstrap resampling. BP value (printed
# in green color by default) is "bootstrap probability" value,
# which is less accurate than AU value as p-value. One can consider
# that clusters (edges) with high AU values (e.g. 95%) are strongly
# supported by data."

# Optimal number of clusters ======================================
# Function to compute a binary dissimilarity matrix from clusters
grpdist <- function(X)
{
  require(cluster)
  gr <- as.data.frame(as.factor(X))
  distgr <- daisy(gr, "gower")
  distgr
}

#For for UPGMA agglomerative clustering
dev.new(
  title = "Optimal number of clusters",
  width = 12,
  height = 8,
  noRStudioGD = TRUE)
par(mfrow = c(1, 2))

# Average silhouette widths (Rousseeuw quality index)
Si <- numeric(nrow(tonga.d))
for (k in 2:(nrow(tonga.d) - 1))
{
  sil <- silhouette(cutree(tonga.UPGMA, k = k), tonga.dc.d)
  Si[k] <- summary(sil)$avg.width
}
k.best <- which.max(Si)
plot(
  1:nrow(tonga.d),
  Si,
  type = "h",
  main = "Silhouette-optimal number of clusters (UPGMA)",
  xlab = "k (number of clusters)",
  ylab = "Average silhouette width"
)
axis(
  1,
  k.best,
  paste("optimum", k.best, sep = "\n"),
  col = "red",
  font = 2,
  col.axis = "red"
)
points(k.best,
       max(Si),
       pch = 16,
       col = "red",
       cex = 1.5
)
# Optimal number of clusters according to matrix correlation 
# statistic (Pearson)
kt <- data.frame(k = 1:nrow(tonga.d), r = 0)
for (i in 2:(nrow(tonga.d) - 1)) 
{
  gr <- cutree(tonga.UPGMA, i)
  distgr <- grpdist(gr)
  mt <- cor(tonga.dc.d, distgr, method = "pearson")
  kt[i, 2] <- mt
}
k.best <- which.max(kt$r)
plot(
  kt$k,
  kt$r,
  type = "h",
  main = "Matrix correlation-optimal number of clusters (UPGMA)",
  xlab = "k (number of clusters)",
  ylab = "Pearson's correlation"
)
axis(
  1,
  k.best,
  paste("optimum", k.best, sep = "\n"),
  col = "red",
  font = 2,
  col.axis = "red"
)
points(k.best,
       max(kt$r),
       pch = 16,
       col = "red",
       cex = 1.5)

#For for Ward's minimum variance clustering
dev.new(
  title = "Optimal number of clusters",
  width = 12,
  height = 8,
  noRStudioGD = TRUE)
par(mfrow = c(1, 2))

# Average silhouette widths (Rousseeuw quality index)
Si <- numeric(nrow(tonga.d))
for (k in 2:(nrow(tonga.d) - 1))
{
  sil <- silhouette(cutree(tonga.ward, k = k), tonga.dc.d)
  Si[k] <- summary(sil)$avg.width
}
k.best <- which.max(Si)
plot(
  1:nrow(tonga.d),
  Si,
  type = "h",
  main = "Silhouette-optimal number of clusters (Ward)",
  xlab = "k (number of clusters)",
  ylab = "Average silhouette width"
)
axis(
  1,
  k.best,
  paste("optimum", k.best, sep = "\n"),
  col = "red",
  font = 2,
  col.axis = "red"
)
points(k.best,
       max(Si),
       pch = 16,
       col = "red",
       cex = 1.5
)


# Optimal number of clusters according to matrix correlation 
# statistic (Pearson)
kt <- data.frame(k = 1:nrow(tonga.d), r = 0)
for (i in 2:(nrow(tonga.d) - 1)) 
{
  gr <- cutree(tonga.ward, i)
  distgr <- grpdist(gr)
  mt <- cor(tonga.dc.d, distgr, method = "pearson")
  kt[i, 2] <- mt
}
k.best <- which.max(kt$r)
plot(
  kt$k,
  kt$r,
  type = "h",
  main = "Matrix correlation-optimal number of clusters (Ward)",
  xlab = "k (number of clusters)",
  ylab = "Pearson's correlation"
)
axis(
  1,
  k.best,
  paste("optimum", k.best, sep = "\n"),
  col = "red",
  font = 2,
  col.axis = "red"
)
points(k.best,
       max(kt$r),
       pch = 16,
       col = "red",
       cex = 1.5)

# Final dendrogram with the selected clusters =====================
#UPGMA
# Choose the number of clusters
#k <- 10
k<- 9 #after comparing, 9 seems to be the best
#k<-8
# Silhouette plot of the final partition
tonga.k <- cutree(tonga.UPGMA, k = k)
sil <- silhouette(tonga.k, tonga.dc.d)
rownames(sil) <- row.names(tonga.d)
dev.new(title = "Silhouette plot - UPGMA - k=9", noRStudioGD = TRUE)
plot(
  sil,
  main = "Silhouette plot - Chord - UPGMA",
  cex.names = 0.6,
  col = 2:(k + 1),
  nmax = 100
)
mfrow(par = c(1,1))

#Ward
k <- 8 #8 seems to be the best
#k<- 9
#k<-10
# Silhouette plot of the final partition
tonga.k <- cutree(tonga.ward, k = k)
sil <- silhouette(tonga.k, tonga.dc.d)
rownames(sil) <- row.names(tonga.d)
dev.new(title = "Silhouette plot - Ward - k=8", noRStudioGD = TRUE)
plot(
  sil,
  main = "Silhouette plot - Chord - Ward",
  cex.names = 0.6,
  col = 2:(k + 1),
  nmax = 100
)
par(mfrow = c(1,1))
#---> 8 seems to be best for Ward
######################## NEED TO LOAD SPATIAL MATRIX ######################################################
#Extract coordinates --> spatial matrix
#longitude values are considered the x-coordinate, while latitude values are the y-coordinate 
mlat<-cast(tonga, formula = site~., mean, value = "lat", fill = 0) 
mlong<-cast(tonga, formula = site~., mean, value = "long", fill = 0)
tonga.gps<-data.frame(mlong, mlat)
ugh<-data.frame(tonga.gps$site, tonga.gps$X.all., tonga.gps$X.all..1)
setnames(ugh, old = c("tonga.gps.site", "tonga.gps.X.all.", "tonga.gps.X.all..1"), 
         new = c('site','lon','lat'))
tonga.gps<-ugh
tonga.gps<-column_to_rownames(tonga.gps, var="site")

tonga.xy<- geoXY(tonga.gps$lat, tonga.gps$lon, unit = 1000)
tonga.xy<-as.data.frame(tonga.xy, row.names=ugh$site)
View(tonga.xy)
plot(tonga.xy$X~tonga.xy$Y)
plot(tonga.gps$lon~tonga.gps$lat)

#SUBSET OF 30 SITES NOT USED 
#mlat<-cast(tonga30, formula = site~., mean, value = "lat", fill = 0) 
#mlong<-cast(tonga30, formula = site~., mean, value = "long", fill = 0)
#tonga30.gps<-data.frame(mlong, mlat)
#ugh30<-data.frame(tonga30.gps$site, tonga30.gps$X.all., tonga30.gps$X.all..1)
#setnames(ugh30, old = c("tonga30.gps.site", "tonga30.gps.X.all.", "tonga30.gps.X.all..1"), 
#         new = c('site','lon','lat'))
#t30.gps<-ugh30
#t30.gps<-column_to_rownames(t30.gps, var="site")
#t30.gps
#t30.xy <- geoXY(t30.gps$lat, t30.gps$lon, unit = 1000)
#t30.xy<-as.data.frame(t30.xy, row.names = ugh30$site) #wow it was that easy to not have to use excel 
#View(t30.xy)
#############################################################################
# Plot the Clusters on the map (and compare maps, with different methods/k)
#UPGMA
#k <- 10
k<- 9 #after comparing, 9 seems to be the best
#k<-8
tonga.k <- cutree(tonga.UPGMA, k = k)
dev.new(title = "UPGMA mapped clusters",
        width = 9,
        noRStudioGD = TRUE)
drawmap(xy = tonga.xy,
        clusters = tonga.k,
        main = "UPGMA mapped clusters")
drawmap(xy = tonga.xy,
        clusters = tonga.k,
        main = "UPGMA mapped clusters"
)

#Ward
#k <- 8 
k<- 9 # for more accurate comparisons, we will stick to the same number
#k<-10
tonga.k <- cutree(tonga.ward, k = k)
dev.new(title = "Ward's mapped clusters",
        width = 9,
        noRStudioGD = TRUE)
drawmap(xy = tonga.xy,
        clusters = tonga.k,
        main = "Ward's mapped clusters")
drawmap(xy = tonga.xy,
        clusters = tonga.k,
        main = "Ward's mapped clusters"
)

#Principal Component Analysis with clusters
##Extract sites/species scores 
## extract % explained by the first 2 axes
perc <- round(100*(summary(tonga.dc.pca)$cont$importance[2, 1:2]), 2)
site.scores <- as.data.frame(scores(tonga.dc.pca, display = "sites", scaling = 1))
site.scores<-tibble::rownames_to_column(site.scores, "sites")
site.scores
spec.scores <- as.data.frame(scores(tonga.dc.pca, display=c("species"), scaling=1, center=TRUE))
spec.scores
species.R2 <- goodness(tonga.dc.pca, display="species", model="CA")
which((species.R2[,2] >= 0.45)==TRUE)
spec.scores.45 <- spec.scores[c(18,94,98,102,233,235),]
spec.scores.45
const=0.19
spec.scores.45<-spec.scores.45*const
#If we wanted to make the circle: 
#scale.fac <- attributes(spec.scores.45)$const
#scale.fac
#rad <- sqrt(2 /60)
#rad <- scale.fac * rad

## Hierarchical clustering
#Once you have an adequat distance matrix you can compute hierarchichal clustering using different --> see "clustering"
#ward
tonga.ward <- hclust(tonga.dc.d, method = "ward.D2") # ward clustering (should already be here)
plot(tonga.ward, main = "Ward")

#You can use the *cutree* function to tranform a grouping level to a (unordered) factor, for example: 
ward.k9 <- cutree(tonga.ward, k=9)
ward.f<-as.data.frame(ward.k9)
ward.f <- tibble::rownames_to_column(ward.f, "sites")
ward.plot <- merge(site.scores, ward.f, by="sites")
ward.plot<-column_to_rownames(ward.plot,var="sites")
#make all the different clusters
ward1<-ward.plot[ward.plot$ward.k9 == "1",]
ward2<-ward.plot[ward.plot$ward.k9 == "2",]
ward3<-ward.plot[ward.plot$ward.k9 == "3",]
ward4<-ward.plot[ward.plot$ward.k9 == "4",]
ward5<-ward.plot[ward.plot$ward.k9 == "5",]
ward6<-ward.plot[ward.plot$ward.k9 == "6",]
ward7<-ward.plot[ward.plot$ward.k9 == "7",]
ward8<-ward.plot[ward.plot$ward.k9 == "8",]
ward9<-ward.plot[ward.plot$ward.k9 == "9",]
#Set up a blank plot with scaling, axes, and labels
#double check 
palette(hcl.colors(10, palette = "Dynamic"))
par(mfrow = c(1,1))
dev.off()
plot(tonga.dc.pca,
     scaling = 1, # set scaling type 
     type = "none", # this excludes the plotting of any points from the results
     frame = TRUE,
     # set axis limits
     ylim = c(-0.2,0.35),
     xlim = c(-0.2,0.3),
     # label the plot (title, and axes)
     main = "Biplot PCA with Ward Clustering - scaling 1",
     xlab = paste0("PCA1 (", perc[1], "%)"), 
     ylab = paste0("PCA2 (", perc[2], "%)")
)
points(data = ward1, PC2~PC1, pch = 19, col = "2")+
  points(data = ward2, PC2~PC1, pch = 19, col = "3")+
  points(data = ward3, PC2~PC1, pch = 19, col = "4")+
  points(data = ward4, PC2~PC1, pch = 19, col = "5")+
  points(data = ward5, PC2~PC1, pch = 19, col = "6")+
  points(data = ward6, PC2~PC1, pch = 19, col = "7")+
  points(data = ward7, PC2~PC1, pch = 19, col = "8")+
  points(data = ward8, PC2~PC1, pch = 19, col = "9")+
  points(data = ward9, PC2~PC1, pch = 19, col = "10")+
  text(x = ward.plot[,1]+0.02, # adjust text coordinate to avoid overlap with arrow tip
       y = ward.plot[,2], 
       labels = rownames(ward.plot), 
       col = "black", 
       cex = .5, 
       font = 1)
arrows(0,0, spec.scores.45[,1], spec.scores.45[,2], col = "1", length = 0.05)
# add text labels for arrows
text(x = spec.scores.45[,1]+0.02 , # adjust text coordinate to avoid overlap with arrow tip
     y = spec.scores.45[,2], 
     labels = rownames(spec.scores.45), 
     col = "1", 
     cex = .7, 
     font = 1)
# add legend 
legend("topright",
       legend=c("Cluster 1", "Cluster 2", "Cluster 3", "Cluster 4", "Cluster 5", "Cluster 6", "Cluster 7", "Cluster 8", "Cluster 9"),
       col = c("2", "3", "4", "5", "6", "7", "8", "9", "10"),
       pch=19,
       cex=1,
       bty="n")

#"FAILED" ATTEMPT BELOW,
#library(viridis)
#ugh<-ggplot(ward.plot, aes(PC1, PC2, col=as.factor(ward.k9), type="p")) + 
#  scale_color_viridis(discrete = TRUE, option = "H") +
#  labs(title="Principal Component Analysis of Sites ",
#       x ="PC1 (18.75%)", y = "PC2 (17.21%)")+
#  geom_point(size=2) +  
#  theme(legend.position="none")+
#  geom_hline(yintercept = 0, lty = 2) +
#  geom_vline(xintercept = 0, lty = 2) +
#  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
#        panel.background = element_blank(), axis.line = element_line(colour = "black"))+
#  geom_text(aes(label = rownames(ward.plot), color=NULL), size = 3, nudge_x = 0.012)

###########################################
#UPGMA
tonga.UPGMA <- hclust(tonga.dc.d, method = "average") # UPGMA clustering
plot(tonga.UPGMA, main = "UPGMA")
#You can use the *cutree* function to tranform a grouping level to a (unordered) factor, for example: 
UPGMA.k9 <- cutree(tonga.UPGMA, k=9)
UPGMA.f<-as.data.frame(UPGMA.k9)
UPGMA.f

UPGMA.f <- tibble::rownames_to_column(UPGMA.f, "sites")
UPGMA.plot <- merge(site.scores, UPGMA.f, by="sites")
UPGMA.plot<-column_to_rownames(UPGMA.plot,var="sites")
#UPGMA points
UPGMA1<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "1",]
UPGMA2<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "2",]
UPGMA3<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "3",]
UPGMA4<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "4",]
UPGMA5<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "5",]
UPGMA6<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "6",]
UPGMA7<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "7",]
UPGMA8<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "8",]
UPGMA9<-UPGMA.plot[UPGMA.plot$UPGMA.k9 == "9",]
#Set up a blank plot with scaling, axes, and labels
par(mfrow = c(1,1))
plot(tonga.dc.pca,
     scaling = 1, # set scaling type 
     type = "none", # this excludes the plotting of any points from the results
     frame = TRUE,
     # set axis limits
     ylim = c(-0.2,0.35),
     xlim = c(-0.2,0.3),
     # label the plot (title, and axes)
     main = "Biplot PCA with UPGMA Clustering- scaling 1",
     xlab = paste0("PCA1 (", perc[1], "%)"), 
     ylab = paste0("PCA2 (", perc[2], "%)") 
)
points(data = UPGMA1, PC2~PC1, pch = 19, col = "2")+
  points(data = UPGMA2, PC2~PC1, pch = 19, col = "3")+
  points(data = UPGMA3, PC2~PC1, pch = 19, col =  "4")+
  points(data = UPGMA4, PC2~PC1, pch = 19, col = "5")+
  points(data = UPGMA5, PC2~PC1, pch = 19, col = "6")+
  points(data = UPGMA6, PC2~PC1, pch = 19, col = "7")+
  points(data = UPGMA7, PC2~PC1, pch = 19, col = "8")+
  points(data = UPGMA8, PC2~PC1, pch = 19, col = "9")+
  points(data = UPGMA9, PC2~PC1, pch = 19, col = "10")+
  text(x = UPGMA.plot[,1]+0.02, # adjust text coordinate to avoid overlap with arrow tip
       y = UPGMA.plot[,2], 
       labels = rownames(UPGMA.plot), 
       col = "black", 
       cex = .5, 
       font = 1)
arrows(0,0, spec.scores.45[,1], spec.scores.45[,2], col = "1", length = 0.05)
# add text labels for arrows
text(x = spec.scores.45[,1]+0.02 , # adjust text coordinate to avoid overlap with arrow tip
     y = spec.scores.45[,2], 
     labels = rownames(spec.scores.45), 
     col = "1", 
     cex = .7, 
     font = 1)
# add legend 
legend("topright",
       legend=c("Cluster 1", "Cluster 2", "Cluster 3", "Cluster 4", "Cluster 5", "Cluster 6", "Cluster 7", "Cluster 8", "Cluster 9"),
       col = c("2", "3", "4", "5", "6", "7", "8", "9", "10"),
       pch=19,
       cex=1,
       bty="n")

####### ENVIRONMENTAL VARIABLE EXPLORATION AND ANALYSES #####################################
#note - no subsetted data used
env <- read_excel("tongu_data.xlsx", 
                  sheet = "env", col_types = c("text", 
                                               "numeric", "numeric", "numeric", 
                                               "numeric", "numeric", "numeric", "numeric", 
                                               "text", "text"))
env1<-env[1:8]%>%
  group_by(site) %>%
  summarize(across(.fns = mean))

#Feeding type by biomass 
env2<-food.b <- read_excel("tongu_data.xlsx", 
                           sheet = "food.b")
env2<-env2%>%
  group_by(site) %>%
  summarize(across(.fns = sum))

#Feeding type by density
env3<-food.d <- read_excel("tongu_data.xlsx", 
                           sheet = "food.d")
env3<-env3%>%
  group_by(site) %>%
  summarize(across(.fns = sum))

#Feeding type by richness
env4<-food.r <- read_excel("tongu_data.xlsx", 
                           sheet = "food.r")
env4<-env4%>%
  group_by(site) %>%
  summarize(across(.fns = sum))

#Distances to location
env5<-distance <- read_excel("tongu_data.xlsx", 
                             sheet = "distance")
env5<-env5%>%
  group_by(site) %>%
  summarize(across(.fns = mean))

#Benthic %cover
env6<-benthic <- read_excel("tongu_data.xlsx", 
                            sheet = "benthic")
env6<-env6%>%
  group_by(site) %>%
  summarize(across(.fns = mean))

#%Cover by total "groups
env7<-cover<- read_excel("tongu_data.xlsx", 
                         sheet = "cover")
env7<-env7%>%
  group_by(site) %>%
  summarize(across(.fns = mean))

######################################
##Subset of 30 sites, skip to line 1365
#env1.30<-subset(env1,site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
#env2.30<-subset(env2, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
#env3.30<-subset(env3, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
#env4.30<-subset(env4, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))

#env5.30<-subset(env5, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
# env6.30<-subset(env6, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
#env7.30<-subset(env7, site %in%  c("Afa",
#                                   "American warf",
#                                   "Ata prison close",
#                                   "Ata prison north",
#                                   "Atata FHR 1",
#                                   "Atata SMA 3",
#                                   "Eueiki SMA 3",
#                                   "Euiki FHR 1",
#                                   "Fafa 3",
#                                   "Fafa control close",
#                                  "Fafa Far control 1",
#                                  "Haatafu FHR Resort",
#                                  "Hakau Manu 1",
#                                  "Kolonga FHR",
#                                  "Kolonga SMA",
#                                  "Lagoon Entrance 2",
#                                  "Malinoa 1",
#                                  "Malinoa 2",
#                                   "Middle reefs close",
#                                   "Military Island 1",
#                                   "Nuku bommie 1",
#                                   "Nuku Island close",
#                                   "Nuku Outside 2",
#                                   "Palace",
#                                   "Pangaimotu control",
#                                   "Sopu Mid",
#                                   "Tao Mid",
#                                   "Tao North",
#                                   "Tokatoka 1",
#                                   "Tokatoka Far bommie"))
#env1.30$site<-abbreviate(env1.30$site)
#env2.30$site<-abbreviate(env2.30$site)
#env3.30$site<-abbreviate(env3.30$site)
#env4.30$site<-abbreviate(env4.30$site)
#env5.30$site<-abbreviate(env5.30$site)
#env6.30$site<-abbreviate(env6.30$site)
#env7.30$site<-abbreviate(env7.30$site)
#e31<-column_to_rownames(env1.30, var = "site")
#e32<-column_to_rownames(env2.30, var = "site")
#e33<-column_to_rownames(env3.30, var = "site")
#e34<-column_to_rownames(env4.30, var = "site")
#e35<-column_to_rownames(env5.30, var = "site")
#e36<-column_to_rownames(env6.30, var = "site")
#e37<-column_to_rownames(env7.30, var = "site")

#### Subset data exploration 
#e31.stand <- scale(e31)
#env.pca <- rda(e31.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#feeding biomass
#e32.stand <- e32
#env.pca <- rda(e32.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#feeding density
#e33.stand <- e33
#env.pca <- rda(e33.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#feeding richness
#e34.stand <- scale(e34)
#env.pca <- rda(e34.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#distance to things
#e35.stand <- scale(e35)
#env.pca <- rda(e35.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#benthic
#e36.stand <- e36
#env.pca <- rda(e36.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#cover
#e37.stand <- e37 #scale or no
#env.pca <- rda(e37.stand)
#screeplot(env.pca, bstick=TRUE)
#summary(env.pca)
#cleanplot.pca(env.pca, scaling = 1)
#############################################################

env1$site<-abbreviate(env1$site)
env2$site<-abbreviate(env2$site) #will not be used, possibly for functional diversity
env3$site<-abbreviate(env3$site) #will not be used, possibly for functional diversity
env4$site<-abbreviate(env4$site) #will not be used, possibly for functional diversity
env5$site<-abbreviate(env5$site)
env6$site<-abbreviate(env6$site)
env7$site<-abbreviate(env7$site)
e1.5<-merge(env1, env5, by="site") #combine e1 and e5
e1.5.7<-merge(e1.5, env7, by="site") #combine e1, e5, and e7
e1<-column_to_rownames(env1, var = "site")
e2<-column_to_rownames(env2, var = "site") #will not be used, possibly for functional diversity
e3<-column_to_rownames(env3, var = "site") #will not be used, possibly for functional diversity
e4<-column_to_rownames(env4, var = "site") #will not be used, possibly for functional diversity
e5<-column_to_rownames(env5, var = "site")
e6<-column_to_rownames(env6, var = "site")
e7<-column_to_rownames(env7, var = "site")
e1.5<-column_to_rownames(e1.5, var = "site")
e1.5.7<-column_to_rownames(e1.5.7, var="site")

#Explore Data, check for multicolinearity, consider transformations, or atleast acknowledge their presence
#e1
par(mfrow=c(1,1))
for (i in 1:ncol(e1)) {
  cur_var <- colnames(e1)[i]
  hist(e1[,i], xlab = cur_var, main = cur_var)
} 
par(mfrow=c(1,2))
for (i in 1:ncol(e1)) {
  cur_var <- colnames(e1)[i]
  hist(e1[,i], xlab = cur_var, main = cur_var)
  cur_var <- paste("log(", cur_var, ")", sep = "")
  hist(log(e1[,i]), xlab = cur_var, main = cur_var)
} 

#e5
par(mfrow=c(1,1))
for (i in 1:ncol(e5)) {
  cur_var <- colnames(e5)[i]
  hist(e5[,i], xlab = cur_var, main = cur_var)
} 
par(mfrow=c(1,2))
for (i in 1:ncol(e5)) {
  cur_var <- colnames(e5)[i]
  hist(e5[,i], xlab = cur_var, main = cur_var)
  cur_var <- paste("log(", cur_var, ")", sep = "")
  hist(log(e5[,i]), xlab = cur_var, main = cur_var)
} 

#e6
par(mfrow=c(1,1))
for (i in 1:ncol(e6)) {
  cur_var <- colnames(e6)[i]
  hist(e6[,i], xlab = cur_var, main = cur_var)
} 
par(mfrow=c(1,2))
for (i in 1:ncol(e6)) {
  cur_var <- colnames(e6)[i]
  hist(e6[,i], xlab = cur_var, main = cur_var)
  cur_var <- paste("log(", cur_var, ")", sep = "")
  hist(log(e6[,i]), xlab = cur_var, main = cur_var)
} 
#e7
par(mfrow=c(1,1))
for (i in 1:ncol(e7)) {
  cur_var <- colnames(e7)[i]
  hist(e7[,i], xlab = cur_var, main = cur_var)
} 
par(mfrow=c(1,2))
for (i in 1:ncol(e7)) {
  cur_var <- colnames(e7)[i]
  hist(e7[,i], xlab = cur_var, main = cur_var)
  cur_var <- paste("log(", cur_var, ")", sep = "")
  hist(log(e7[,i]), xlab = cur_var, main = cur_var)
} 
par(mfrow=c(1,1))

#VIF, will probably use Kobe's function, it's better (and vif.cca later on)
#library(car)
#mod_full<-lm(depth~., data=e1)
#vif(mod_full)
#mod_full<-lm(market~., data=e5)
#vif(mod_full)
#mod_full<-lm(Turf~., data=e6)
#vif(mod_full)
#mod_full<-lm(hard~., data=e7)
#vif(mod_full)
#--> all below 5, no multicolinearity detected

#kobe's function:
VIF_analysis <- function(x){
  x <- as.data.frame(x)
  
  varname <- vector()
  Rsquared <- vector()
  VIF <- vector()
  
  for(i in 1:ncol(x)){
    varname <- c(varname, colnames(x)[i])
    mod <- lm(data=x[,-i], x[,i]~.)
    
    R2 <- summary(mod)$r.squared
    Rsquared <- c(Rsquared,R2)
    
    VIF <- c(VIF,1/(1-R2))
  }
  output <- data.frame(variable=varname, Rsquared=Rsquared, VIF=VIF)
}

(VIF_analysis(e1)) #none over 5
(VIF_analysis(e5)) #none over 5
(VIF_analysis(e6)) #essentially perfect fit: summary may be unreliable
e6<-e6[,-1] #new env matrix
(VIF_analysis(e6))
(VIF_analysis(e7))
(VIF_analysis(e7[,-1])) #none over 5
e7<-e7[,-1] #new env matrix
(VIF_analysis(e7))
(VIF_analysis(e1.5)) #market VIF > 5 
(VIF_analysis(e1.5[-11]))
e1.5<-e1.5[,-11] #new env matrix
(VIF_analysis(e1.5.7)) #market VIF > 5 
(VIF_analysis(e1.5.7[,-14, -3]))
(VIF_analysis(dplyr::select(e1.5.7, -3, -14))) #remove algae and sst
e1.5.7<-dplyr::select(e1.5.7, -3, -14) #new env matrix
(VIF_analysis(e1.5.7)) 

#################################
### PCA of environmental variables 
e1.stand <- scale(e1)
env.pca <- rda(e1.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.3741 0.5951
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#feeding biomass
e2.stand <- scale(e2)
env.pca <- rda(e2.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.3477 0.5173
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#feeding density
e3.stand <- scale(e3)
env.pca <- rda(e3.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.2994 0.5023
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#feeding richness
e4.stand <- scale(e4)
env.pca <- rda(e4.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.3659 0.5463
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#distance to things
e5.stand <- scale(e5)
env.pca <- rda(e5.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.3598 0.5987
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#benthic
e6.stand <- e6
env.pca <- rda(e6.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion   0.6473   0.8390 
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)
#!!!Acr_br, #CCA, #turf

View(e7)
#cover
e7.stand <- scale(e7) 
env.pca <- rda(e7.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.348 0.5487
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#general + distance
e1.5.stand <- scale(e1.5) 
env.pca <- rda(e1.5.stand)
par(mfrow = c(1,1))
screeplot(env.pca, bstick=TRUE)
summary(env.pca) #Cumulative Proportion 0.348 0.5487
par(mfrow = c(1,2))
cleanplot.pca(env.pca, scaling = 1)
cleanplot.pca(env.pca, scaling = 2)

#=====================================================================================
#Environmental data: 
#after data visualization, we are most interested in e1 (general), e5 (distances), e7 (benthic cover)
#tonga.env = e1 + e5 + e7
#e1.5 = e1 + e5 
#we will see what should be tested separately, together, and finish with a clean tonga.env
site.scores <- as.data.frame(scores(tonga.dc.pca, display = "sites", scaling = 1)) #should already be loaded

#general env
mod.pc1.e1 <- lm(site.scores$PC1~., e1)
summary(mod.pc1.e1) #sst, rugosity
mod.pc2.e1 <- lm(site.scores$PC2~., e1)
summary(mod.pc2.e1) #sst

#distances
mod.pc1.e5 <- lm(site.scores$PC1~., e5)
summary(mod.pc1.e5) #20m, market, village
mod.pc2.e5 <- lm(site.scores$PC2~., e5)
summary(mod.pc2.e5) #20m, lagoon, village

#benthic cover
mod.pc1.e7 <- lm(site.scores$PC1~., e7)
summary(mod.pc1.e7) #invert
mod.pc2.e7 <- lm(site.scores$PC2~., e7)
summary(mod.pc2.e7) #none? 


#Stepwise selection 
#PC1
zero.pc1.e1<- lm(site.scores$PC1~1, e1)
mod.pc1.e1.red <- step(zero.pc1.e1, formula(mod.pc1.e1), direction="both")
summary(mod.pc1.e1.red) 
mod.pc1.e1.red$anova
# AIC=-250.15 : PC1 ~ sst +  rugosity 

#PC2
zero.pc2.e1 <- lm(site.scores$PC2~1, e1)
mod.pc2.e1.red <- step(zero.pc2.e1, formula(mod.pc2.e1), direction="both")
summary(mod.pc2.e1.red)
# AIC=-254.87 : PC2 ~depth 

#PC1
zero.pc1.e5<- lm(site.scores$PC1~1, e5)
mod.pc1.e5.red <- step(zero.pc1.e5, formula(mod.pc1.e5), direction="both")
summary(mod.pc1.e5.red)
#AIC=-261.39: PC1 ~ market + `20m` + village 

#PC2
zero.pc2.e5 <- lm(site.scores$PC2~1, e5)
mod.pc2.e5.red <- step(zero.pc2.e5, formula(mod.pc2.e5), direction="both")
summary(mod.pc2.e5.red)
#AIC=-273.89: PC1 ~ `20m` + market + village + lagoon

#PC1
zero.pc1.e7<- lm(site.scores$PC1~1, e7)
mod.pc1.e7.red <- step(zero.pc1.e7, formula(mod.pc1.e7), direction="both")
summary(mod.pc1.e7.red)
#AIC=-235.76 - PC1 ~ invert 

#PC2
zero.pc2.e7 <- lm(site.scores$PC2~1, e7)
mod.pc2.e7.red <- step(zero.pc2.e7, formula(mod.pc2.e7), direction="both")
summary(mod.pc2.e7.red)
#AIC=-239.89 - site.scores$PC2 ~ hard + soft

######################
rda.e1 <- rda(tonga.dc, e1)
RsquareAdj(rda.e1) # this provides an unbiased estimate of explained variance (0.1332588)
anova(rda.e1) # this performs a permutation test where the Null Hypothesis is that the models does not explain a 
# significant proportion of the variance of Y.

rda.e5 <- rda(tonga.dc, e5)
RsquareAdj(rda.e5) # 0.1573721
anova(rda.e5)  #sign

rda.e7 <- rda(tonga.dc, e7)
RsquareAdj(rda.e7) #very low..., let's try e6?
anova(rda.e7) #sign

rda.e6 <- rda(tonga.dc, e6)
RsquareAdj(rda.e6) #0.1567958
anova(rda.e6) #sign
#########################

## Direct gradient analysis : redundancy analysis (RDA)
mod0.e1<-rda(tonga.dc~1, e1)
mod1.e1<-rda(tonga.dc~., e1)
step.e1<-ordiR2step(mod0.e1, mod1.e1)
mod1.e1 
step.e1$call #rda(formula = tonga.dc ~ depth + rugosity + sst + wave, data = e1)
step.e1$anova
e1.rda<-rda(tonga.dc ~ depth + rugosity + sst + wave, data = e1) 
RsquareAdj(e1.rda) # 0.1200259

## Direct gradient analysis : redundancy analysis (RDA)
mod0.e5<-rda(tonga.dc~1, e5)
mod1.e5<-rda(tonga.dc~., e5)
step.e5<-ordiR2step(mod0.e5, mod1.e5)
step.e5$call #rda(formula = tonga.dc ~ market + `20m` + village, data = e5)
step.e5$anova 
RsquareAdj(step.e5)


## Direct gradient analysis : redundancy analysis (RDA)
mod0.e7<-rda(tonga.dc~1, e7)
mod1.e7<-rda(tonga.dc~., e7)
step.e7<-ordiR2step(mod0.e7, mod1.e7)
step.e7$call
step.e7$anova

## Direct gradient analysis : redundancy analysis (RDA)
mod0.e6<-rda(tonga.dc~1, e6)
mod1.e6<-rda(tonga.dc~., e6)
step.e6<-ordiR2step(mod0.e6, mod1.e6, method="forward")
step.e6$call
step.e6$anova

## Direct gradient analysis : redundancy analysis (RDA)
mod0.e1.5<-rda(tonga.dc~1, e1.5)
mod1.e1.5<-rda(tonga.dc~., e1.5)
step.e1.5<-ordiR2step(mod0.e1.5, mod1.e1.5)
step.e1.5$call
step.e1.5$anova
?ordistep()

## Direct gradient analysis : redundancy analysis (RDA)
mod0.e1.5.7<-rda(tonga.dc~1, e1.5.7)
mod1.e1.5.7<-rda(tonga.dc~., e1.5.7)
step.e1.5.7<-ordiR2step(mod0.e1.5.7, mod1.e1.5.7)
step.e1.5.7$call #compare new 
mod1.e1.5.7$call #to old
step.e1.5.7$anova
#note, the R2Adj increases to  0.32907 for hard when considered with other variables

#Comapre all adjusted R2
(e1R2adj <- RsquareAdj(step.e1)$adj.r.squared)
(e5R2adj <- RsquareAdj(step.e5)$adj.r.squared)
(e6R2adj <- RsquareAdj(step.e6)$adj.r.squared)
(e7R2adj <- RsquareAdj(step.e7)$adj.r.squared)
(e15R2adj <- RsquareAdj(step.e1.5)$adj.r.squared)
(e157R2adj <- RsquareAdj(step.e1.5.7)$adj.r.squared) #best

#Plot 
source("./final/functions/triplot.rda.R")

# PRETTY MUCH THE SAME USING FOWARD.SEL OR ORDISTEP, COMPARE TRIPLOTS
#e1.sel <- forward.sel(tonga.dc, e1)
#rda.e1.sel <- rda(tonga.dc, e1[e1.sel$order])
#summary(rda.e1.sel) # Big output, but DO do look at it.
#RsquareAdj(rda.e1.sel)
#anova(rda.e1.sel)
#par(mfrow = c(1,1))
#triplot.rda(rda.e1.sel, site.sc = "wa")
#triplot.rda(step.e1, site.sc = "wa")
#triplot.rda(rda.e1.sel)
#triplot.rda(step.e1)

#LC OR WA? SO MANY CONTRADICTING PAPERS LOL
par(mfrow = c(1,2))
e1.sp <- goodness(step.e1)
e1.sp<-which((e1.sp[,2] >= 0.3)==TRUE)
triplot.rda(step.e1, select.spe = e1.sp, site.sc="wa")
triplot.rda(step.e1, select.spe = e1.sp, site.sc="lc")

e5.sp <- goodness(step.e5)
e5.sp<-which((e5.sp[,2] >= 0.3)==TRUE)
triplot.rda(step.e5, select.spe = e5.sp, site.sc="wa")
triplot.rda(step.e5, select.spe = e5.sp, site.sc="lc")

e6.sp <- goodness(step.e6)
e6.sp<-which((e6.sp[,2] >= 0.3)==TRUE)
triplot.rda(step.e6, select.spe = e6.sp, site.sc="wa")
triplot.rda(step.e6, select.spe = e6.sp, site.sc="lc")

e7.sp <- goodness(step.e7) #completely PC1
triplot.rda(step.e7, site.sc="wa")
triplot.rda(step.e7,  site.sc="lc")

e1.5.sp <- goodness(step.e1.5)
e1.5.sp<-which((e1.5.sp[,2] >= 0.3)==TRUE)
triplot.rda(step.e1.5, select.spe = e1.5.sp, site.sc="wa")
triplot.rda(step.e1.5, select.spe = e1.5.sp, site.sc="lc")
triplot.rda(step.e1.5, select.spe = e1.5.sp, site.sc="wa", scaling = 2)
triplot.rda(step.e1.5, select.spe = e1.5.sp, site.sc="lc",scaling = 2)

e1.5.7.sp <- goodness(step.e1.5.7)
e1.5.7.sp<-which((e1.5.7.sp[,2] >= 0.3)==TRUE)
triplot.rda(step.e1.5.7, select.spe = e1.5.7.sp, site.sc="wa")
triplot.rda(step.e1.5.7, select.spe = e1.5.7.sp, site.sc="lc")
triplot.rda(step.e1.5.7, select.spe = e1.5.7.sp, site.sc="wa", scaling = 2)
triplot.rda(step.e1.5.7, select.spe = e1.5.7.sp, site.sc="lc", scaling = 2)

##########################################################
##Plot
## extract % explained by the first 2 axes
env.tri<-step.e1.5.7#whichever rda you would like to test

perc.e1 <- round(100*(summary(env.tri)$cont$importance[2, 1:2]), 2)
## extract scores - these are coordinates in the RDA space
env.tri.si <- scores(env.tri, display="sites", choices=c(1,2), scaling=1)
env.tri.si<- as.data.frame(env.tri.si)
env.tri.si <- tibble::rownames_to_column(env.tri.si, "sites")# add rownames as column
ward.k9 <- cutree(tonga.ward, k=9)
ward.f<-as.data.frame(ward.k9)
ward.f <- tibble::rownames_to_column(ward.f, "sites")
env.tri.plot<-merge(env.tri.si, ward.f, by = "sites")
env.tri.plot<-column_to_rownames(env.tri.plot,var="sites")
env.tri.plot
#POINTS
e.ward1<-env.tri.plot[env.tri.plot$ward.k9 == "1",]
e.ward2<-env.tri.plot[env.tri.plot$ward.k9 == "2",]
e.ward3<-env.tri.plot[env.tri.plot$ward.k9 == "3",]
e.ward4<-env.tri.plot[env.tri.plot$ward.k9 == "4",]
e.ward5<-env.tri.plot[env.tri.plot$ward.k9 == "5",]
e.ward6<-env.tri.plot[env.tri.plot$ward.k9 == "6",]
e.ward7<-env.tri.plot[env.tri.plot$ward.k9 == "7",]
e.ward8<-env.tri.plot[env.tri.plot$ward.k9 == "8",]
e.ward9<-env.tri.plot[env.tri.plot$ward.k9 == "9",]
env.tri.sp <- scores(env.tri, display="species", choices=c(1,2), scaling=1) 
which((env.tri.sp[,2] >= 0.4)==TRUE)
env.tri.sp<- env.tri.sp[c(118, 233, 235, 240, 303 ),]
const=0.15 #THIS MIGHT HAVE TO CHANGE DEPENDING ON RDA
env.tri.sp.R2<-env.tri.sp*const
env.tri.bp <- scores(env.tri, display="bp", choices=c(1,2), scaling=1)

# Set up a blank plot with scaling, axes, and labels
#CHECK palette(hcl.colors(10, palette = "Dynamic"))
par(mfrow=c(1,1))
plot(env.tri,
     scaling = 1, # set scaling type 
     type = "none", # this excludes the plotting of any points from the results
     frame = TRUE,
     # set axis limits
     ylim = c(-.4,.4),
     xlim = c(-.4,.4),
     # label the plot (title, and axes)
     main = "Triplot RDA - scaling 1",
     xlab = paste0("RDA1 (", perc.e1[1], "%)"), 
     ylab = paste0("RDA2 (", perc.e1[2], "%)") 
)
points(data = e.ward1, RDA2~RDA1, pch = 19, col = "2")+
  points(data = e.ward2, RDA2~RDA1, pch = 19, col = "3")+
  points(data = e.ward3, RDA2~RDA1, pch = 19, col = "4")+
  points(data = e.ward4, RDA2~RDA1, pch = 19, col = "5")+
  points(data = e.ward5, RDA2~RDA1, pch = 19, col = "6")+
  points(data = e.ward6, RDA2~RDA1, pch = 19, col = "7")+
  points(data = e.ward7, RDA2~RDA1, pch = 19, col = "8")+
  points(data = e.ward8, RDA2~RDA1, pch = 19, col = "9")+
  points(data = e.ward9, RDA2~RDA1, pch = 19, col = "10")+
  text(x = env.tri.plot[,1]+0.02, # adjust text coordinate to avoid overlap with arrow tip
       y = env.tri.plot[,2], 
       labels = rownames(env.tri.plot), 
       col = "black", 
       cex = .5, 
       font = 1)
# add legend 
legend("bottomright",
       legend=c("Cluster 1", "Cluster 2", "Cluster 3", "Cluster 4", "Cluster 5", "Cluster 6", "Cluster 7", "Cluster 8", "Cluster 9"),
       col = c("2", "3", "4", "5", "6", "7", "8", "9", "10"),
       pch=19,
       cex=1,
       bty="n")
# add points for species scores
arrows(0,0,
       env.tri.sp.R2[,1],env.tri.sp.R2[,2], 
       col = "red",
       lwd = 1,
       length = .1)
# add text labels for species abbreviations
text(env.tri.sp.R2,#+ c(-0.09, -0.09), # adjust text coordinates to avoid overlap with points 
     labels = rownames(env.tri.sp.R2), 
     col = "red", 
     font = 1, # bold
     cex = 0.6)
# add arrows for effects of the expanatory variables
arrows(0,0, # start them from (0,0)
       env.tri.bp[,1], env.tri.bp[,2], # end them at the score value
       col = "blue", 
       lwd = 1,
       length = .1)
# add text labels for arrows
text(x = env.tri.bp[,1] , # adjust text coordinate to avoid overlap with arrow tip
     y = env.tri.bp[,2] , 
     labels = rownames(env.tri.bp), 
     col = "blue", 
     cex = .7, 
     font = 1)


## Global test of the RDA result
anova(step.e1, permutations = how(nperm = 999)) #sign
anova(step.e5, permutations = how(nperm = 999)) #sign
anova(step.e6, permutations = how(nperm = 999)) #sign
anova(step.e7, permutations = how(nperm = 999)) #sign
anova(step.e1.5, permutations = how(nperm = 999)) #sign
anova(step.e1.5.7, permutations = how(nperm = 999)) #sign

## Tests of all canonical axes
anova(step.e1, by = "axis", permutations = how(nperm = 999)) #RDA1 and 2
anova(step.e5, by = "axis", permutations = how(nperm = 999)) #RDA1 and 2
anova(step.e6, by = "axis", permutations = how(nperm = 999)) #RDA1 and 2
anova(step.e7, by = "axis", permutations = how(nperm = 999)) #RDA1 
anova(step.e1.5, by = "axis", permutations = how(nperm = 999)) #RDA1, 2, and 3
anova(step.e1.5.7, by = "axis", permutations = how(nperm = 999)) #RDA1, 2, 3, 4, 5


#partial variance using ordiR2step models
step.e1$call
step.e5$call
(part.step.e15<-
    rda(tonga.dc ~ depth + rugosity + sst + wave
        + Condition(market + `20m` + village), data = e1e5))

anova(part.step.e15, permutations = how(nperm = 999)) #Model variance 0.08510
anova(part.step.e15, by = "axis", permutations = how(nperm = 999)) #RDA 1, 2

mod1.e1$call
mod1.e5$call
e1e5<-merge(e1, e5, by = 'row.names', all = TRUE)

part.e15<-
  rda(tonga.dc ~ vis + depth + rugosity + sst + wave + fp + slope
      + Condition(land + market + `20m` + `10m` + village + lagoon), data = e1e5)

anova(part.e15, permutations = how(nperm = 999)) #Model variance 0.11625
anova(part.e15, by = "axis", permutations = how(nperm = 999)) #RDA 1, 2

#Let's compare this to:
anova(mod1.e1.5, permutations = how(nperm = 999)) #Model variance 0.31520
anova(mod1.e1.5, by = "axis", permutations = how(nperm = 999)) #RDA1, 2, and 3

#they are different, maybe do to collinearity? 
vif.cca(part.e15)

#let's try this:
colnames(e1.5) #we had removed market 
#VS
colnames(e1e5)
part2.e15<-
  rda(tonga.dc ~ vis + depth + rugosity + sst + wave + fp + slope
      + Condition(land + `20m` + `10m` + village + lagoon), data = e1e5)#remove market 
#NOW
anova(part2.e15, permutations = how(nperm = 999)) #model variance 0.13050
anova(part2.e15, by = "axis", permutations = how(nperm = 999))#RDA 1, 2, 3
#-->better but it still seems better to combine the e1.e5 prior
#VS
anova(step.e1.5, permutations = how(nperm = 999)) #model 0.27822 (weird, why is the ordiR2 model less than the full model? not adjusted?)
anova(step.e1.5, by = "axis", permutations = how(nperm = 999)) #RDA1, 2, and 3, 4

vif.cca(part2.e15)
vif.cca(part.e15)
vif.cca(step.e1.5)
vif.cca(mod1.e1.5)

(e1.e5R2<- RsquareAdj(mod1.e1.5)$adj.r.squared) #full RDA e1.5 env matric
(e15R2_vif<- RsquareAdj(part2.e15)$adj.r.squared)#partial RDA e1e5 (remove market)
(e15R2<- RsquareAdj(part.e15)$adj.r.squared) #partial RDA e1e5
(stepe1.5.R2<- RsquareAdj(step.e1.5)$adj.r.squared) #ordiRDA e1.5 (I called it e15R2adj earlier)
(e15R2<- RsquareAdj(part.step.e15)$adj.r.squared) #partial RDA (using ordiRDA results from e1, and e5)
#so weird, why does the full e15 model better than the ordistep? 

#Let's try this:
## Direct gradient analysis : redundancy analysis (RDA)
mod0.e1.5<-rda(tonga.dc~1, e1.5)
mod1.e1.5<-rda(tonga.dc~., e1.5)
both.e1.5<-ordistep(mod0.e1.5, mod1.e1.5, directionc="both")
forw.e1.5<-ordistep(mod0.e1.5, mod1.e1.5, directionc="forward")
back.e1.5<-ordistep(mod0.e1.5, mod1.e1.5, directionc="backward")

(RsquareAdj(both.e1.5)$adj.r.squared)
(RsquareAdj(forw.e1.5)$adj.r.squared)
(RsquareAdj(back.e1.5)$adj.r.squared)
(RsquareAdj(step.e1.5)$adj.r.squared)
#so weird... full model is still best? 
vif.cca(mod1.e1.5)

(RsquareAdj(step.e1.5.7)$adj.r.squared)

extractAIC(part2.e15)
extractAIC(part.e15) #snallest AIC 
extractAIC(step.e1.5)
extractAIC(mod1.e1.5)
extractAIC(back.e1.5)
extractAIC(forw.e1.5)
extractAIC(both.e1.5)

par(mfrow = c(1,1))
plot(varpart(tonga.dc, e1, e5, e7))#res = 0.77
plot(varpart(tonga.dc, e1.5, e7)) #res = 0.64, but there is almost nothing they share, this is good good good
varpart(tonga.dc, e1.5, e7) #but there is almost nothing they share, this is good good good
step.e1.5.7$call
plot(varpart(tonga.dc, e1, e5, e6)) #res = 0.69
plot(varpart(tonga.dc, e1.5, e6)) #res = 0.58
plot(varpart(tonga.dc, e1.5.7, e6)) #res = 0.52
#don't forget to look at adjusted R2 for these

################# given these results, let's try this:
mod1.e1.5$call
mod1.e6$call
e15e6<-merge(e1.5, e6, by = 'row.names', all = TRUE)
(part.e15e6<-
    rda(tonga.dc ~  vis + depth + sst + wave + fp + slope + 
          rugosity + land + `10m` + `20m` + lagoon + village
        + Condition(Macro + Turf + Acr_br + Acr_dig + Acr_tab + 
                      AcrEnc + BRA_SMO_Po + ENHr + `FAV-MUS` + `OTH-HC` + POCIL + 
                      Por_mas + TFP_OTH + Mille + `Other Inv` + `OTH-SF` + Soft + 
                      Sponge), data = e15e6))

anova(part.e15e6, permutations = how(nperm = 999)) #Model variance  0.15264 
anova(part.e15e6, by = "axis", permutations = how(nperm = 999)) #RDA 1, 2
vif.cca(part.e15e6) #Turf is over 10, and a few other high ones, let's take off turf

(part2.e15e6<-
    rda(tonga.dc ~  vis + depth + sst + wave + fp + slope + 
          rugosity + land + `10m` + `20m` + lagoon + village
        + Condition(Macro + Acr_br + Acr_dig + Acr_tab + 
                      AcrEnc + ENHr + `FAV-MUS` + `OTH-HC` + POCIL + 
                      Por_mas + TFP_OTH + Mille + `Other Inv` + `OTH-SF` + Soft + 
                      Sponge), data = e15e6))

anova(part2.e15e6, permutations = how(nperm = 999)) #Model variance  0.15790
anova(part2.e15e6, by = "axis", permutations = how(nperm = 999)) #RDA 1, 2
vif.cca(part2.e15e6) #Turf is over 10, and a few other high ones, let's take off turf (and BRA_SMO_Po, taking just turf didnt change much)
#model var with turf+BRA off 0.16868
(RsquareAdj(part.e15e6)$adj.r.squared) # 0.1647218
(RsquareAdj(part2.e15e6)$adj.r.squared) #0.1881689

#Ok, last thing we're going to try: 
mod1.e1.5$call
mod1.e7$call
e15e7<-merge(e1.5, e7, by = 'row.names', all = TRUE)
(part.e15e7<-
    rda(tonga.dc ~  vis + depth + sst + wave + fp + slope + 
          rugosity + land + `10m` + `20m` + lagoon + village
        + Condition(hard + fire + invert + soft + sponge), data = e15e7))

anova(part.e15e7, permutations = how(nperm = 999)) #Model variance 0.25813
anova(part.e15e7, by = "axis", permutations = how(nperm = 999)) #RDA 1, 2, 3
vif.cca(part.e15e7) #all good here
(RsquareAdj(part.e15e7)$adj.r.squared) #0.2753271

###################OK SO THE BEST ENV MATRIX is e1e5e7

(RsquareAdj(mod1.e1.5.7)$adj.r.squared)#why is this higher than 
vif.cca(mod1.e1.5.7) 
#this
(RsquareAdj(step.e1.5.7)$adj.r.squared)

extractAIC(step.e1.5.7) #this has a lower AIC though  -42.05369
extractAIC(mod1.e1.5.7) 
extractAIC(part.e15e7)

##One last check before picking the perfect environmental matrix
##think back to these...
#mod0.e1.5.7<-rda(tonga.dc~1, e1.5.7)
#mod1.e1.5.7<-rda(tonga.dc~., e1.5.7)
#step.e1.5.7<-ordiR2step(mod0.e1.5.7, mod1.e1.5.7)
#step.e1.5.7$call #compare new 
#mod1.e1.5.7$call #to old
#step.e1.5.7$anova

both.e1.5.7<-ordistep(mod0.e1.5.7, mod1.e1.5.7, directionc="both")
forw.e1.5.7<-ordistep(mod0.e1.5.7, mod1.e1.5.7, directionc="forward")
back.e1.5.7<-ordistep(mod0.e1.5.7, mod1.e1.5.7, directionc="backward")

(RsquareAdj(both.e1.5.7)$adj.r.squared)
(RsquareAdj(forw.e1.5.7)$adj.r.squared)
(RsquareAdj(back.e1.5.7)$adj.r.squared)
(RsquareAdj(step.e1.5.7)$adj.r.squared)
#all the same R2: 0.3908369
#which I remind you is lower than:
(RsquareAdj(mod1.e1.5.7)$adj.r.squared) # 0.4091631
#but lower AIC with step. 

extractAIC(both.e1.5.7) #all
extractAIC(forw.e1.5.7) #the
extractAIC(back.e1.5.7) #same
extractAIC(step.e1.5.7) #AIC -42.05369

########## One last look at:
varpart(tonga.dc, e1.5, e7) #res = 0.64

# Tests of all testable fractions
# Test of fraction [a+b]

anova(rda(tonga.dc, e1.5), permutations = how(nperm = 999))
# Test of fraction [b+c]
anova(rda(tonga.dc, e7), permutations = how(nperm = 999))
# Test of fraction [a+b+c]
env.pars <- cbind(e1.5, e7)
anova(rda(tonga.dc, env.pars), permutations = how(nperm = 999))
# Test of fraction [a]
anova(rda(tonga.dc, e1.5, e7),
      permutations = how(nperm = 999)
)
# Test of fraction [c]
anova(rda(tonga.dc, e7, e1.5),
      permutations = how(nperm = 999))
#all components sign 

last<-rda(tonga.dc, env.pars)
(RsquareAdj(last)$adj.r.squared)
extractAIC(last)
colnames(env.pars)
vif.cca(last)

#################### OK so the best is STEP.E1.5.7
step.e1.5.7$call
vif.cca(step.e1.5.7)
tonga.env<-e1.5.7 %>% dplyr::select(market, `20m`, vis, village, rugosity,hard, lagoon, land, wave, fp, slope)

#Compare variables from full to ordiR2 selection 
colnames(e1.5.7)
colnames(tonga.env)

#sneak peak 
plot(varpart(tonga.dc, e1.5.7, tonga.xy)) 
plot(varpart(tonga.dc, tonga.env, tonga.xy))

#################################################
#Variation Partioning Plots
par(mfrow = c(1,2))

plot(part2.e15, 
     scaling = 1, #scaling 1 
     display = c("sp", "lc", "cn"), 
     main = "Triplot RDA  - scaling 1 - lc scores")
spe3.sc <- 
  scores(part2.e15, choices = 1:2, scaling = 1, display = "sp")
arrows(0, 0, spe3.sc[, 1] * 0.92, spe3.sc[, 2] * 0.92, length = 0, lty = 1, col = "red")
plot(part2.e15, # Scaling 2
     display = c("sp", "lc", "cn"), 
     main = "Triplot RDA - scaling 2 - lc scores")
spe4.sc <- 
  scores(part2.e15, choices = 1:2, display = "sp" )
arrows(0, 0, spe4.sc[, 1] * 0.88, spe4.sc[, 2] * 0.88, length = 0, lty = 1, col = "red")

#for full mod e1+e5
plot(mod1.e1.5, 
     scaling = 1, #scaling 1
     display = c("sp", "lc", "cn"), 
     main = "Triplot RDA  - scaling 1 - lc scores")
spe3.sc <- 
  scores(mod1.e1.5, choices = 1:2, scaling = 1, display = "sp")
arrows(0, 0, spe3.sc[, 1] * 0.92, spe3.sc[, 2] * 0.92, length = 0, lty = 1, col = "red")
plot(mod1.e1.5,  # Scaling 2
     display = c("sp", "lc", "cn"), 
     main = "Triplot RDA - scaling 2 - lc scores")
spe4.sc <- 
  scores(mod1.e1.5, choices = 1:2, display = "sp" )
arrows(0, 0, spe4.sc[, 1] * 0.88, spe4.sc[, 2] * 0.88, length = 0, lty = 1, col = "red")

##Why are these so different? 



## 1. Variation partitioning with all explanatory variables
(e1e5.part <- varpart(tonga.dc, e1,e5))
## 2. Variation partitioning after forward selection of explanatory variables
# Separate forward selection in each subset of environmental 
e1.rda <- rda(tonga.dc, e1)
R2a.e1.rda<- RsquareAdj(e1.rda)$adj.r.squared
forward.sel(tonga.dc, 
            e1, 
            adjR2thresh = R2a.e1.rda, 
            nperm = 9999)
e5.rda <- rda(tonga.dc, e5)
R2a.e5.rda<- RsquareAdj(e5.rda)$adj.r.squared
forward.sel(tonga.dc, 
            e5, 
            adjR2thresh = R2a.e5.rda, 
            nperm = 9999)


# Parsimonious subsets of explanatory variables, based on forward 
# selections
e1.pars <- e1[, c(2,7,3,4)]
e5.pars <- e5[, c(4, 3)]

# Variation partitioning
(e1.e5.part <- varpart(tonga.dc, e1.pars, e5.pars))
par(mrfow = c(1,1))
plot(e1.e5.part, 
     digits = 2, 
     bg = c("red", "blue"), 
     Xnames = c("E1 (forward)", "E5 (forward)"), 
     id.size = 0.7
)
plot(e1e5.part, digits = 2, bg = c("red", "blue"), Xnames = c("E1", "E5"))

############################ SPATIAL ANALYSIS ##############################################
library(ape)
library(spdep)
library(ade4)
library(adegraphics)
library(adespatial)

source("final/functions/plot.links.R")
source("final/functions/sr.value.R")
source("final/functions/scalog.R")

## Spatial data: linear trends
#Can we explan anything with just using the *xy* coordinates of the stations ? 
rda.xy <- rda(tonga.dc, tonga.xy)
summary(rda.xy) # Big output, but DO do look at it.
RsquareAdj(rda.xy) 
anova(rda.xy)
# 0.12 explained with linear coordinates, so the residuals contain...
var.res=1-0.1198403 #= 0.8801597
var.res #so, this is what's left to explain with (not linear coordinates)

# Transform the data
tonga.dc <- tonga.bkmc
#if we try with biomass instead of density, less variation is explained
#only 6 MEMs are sign with an AdjR2 0.1169005

#we will be using tonga.dc (tonga density chord )
#tonga.xy.c <- scale(tonga.xy, center = TRUE, scale = FALSE)
tonga.xy.c<-scale(tonga.xy, center = TRUE, scale = FALSE)


# Mantel correlogram of the reef fish tonga data ====================
# DETREND SPECIES DATA, WHY? 
#Long environmental gradients often support a succession of species. Since the
#species that are controlled by environmental factors tend to have unimodal distributions, 
#a long gradient may encompass sites that, at opposite ends of the gradient,
#have no species in common; thus, their dissimilarity has the maximum possible
#value4 (or their similarity is 0). But if one starts at any one point along the gradient
#and walks slowly towards an end, successive sites grow more and more different
#from the starting point until the maximum value of D is reached. Therefore, instead
#of a straight line, the gradient is represented as an arch on a pair of CA axes. 

tonga.dc.det <- resid(lm(as.matrix(tonga.dc) ~ ., data = tonga.xy)) #detrend 
#Regress your species data to the linear coordinates
#From this regression take the 'detrended' residuals.
tonga.dc.D1 <- dist(tonga.dc.det) #turn detrend into distance
(tonga.correlog <- 
    mantel.correlog(tonga.dc.D1, 
                    XY = tonga.xy, 
                    nperm = 999))
summary(tonga.correlog)

# Number of classes
tonga.correlog$n.class # or: tonga.correlog[2]
# Break points
tonga.correlog$break.pts # or: tonga.correlog[3]

# Plot the Mantel correlogram
dev.new(
  title = "Mantel correlogram of tonga data", 
  width = 9, 
  height = 5, 
  noRStudioGD = TRUE
)
plot(tonga.correlog)


# Trend-surface analysis ==========================================
# Computation of a raw (non-orthogonal) third-degree polynomial 
# function on the previously centred X-Y coordinates
tonga.poly <- poly(as.matrix(tonga.xy.c), degree = 3, raw = TRUE)
colnames(tonga.poly) <- 
  c("X", "X2", "X3", "Y", "XY", "X2Y", "Y2", "XY2", "Y3")

# RDA with all 9 polynomial terms
(tonga.trend.rda <- rda(tonga.dc ~ ., 
                        data = as.data.frame(tonga.poly)))

# Computation of the adjusted R^2
(R2adj.poly <- RsquareAdj(tonga.trend.rda)$adj.r.squared) # 0.3299144, 

# RDA using a third-degree orthogonal polynomial of the geographic 
# coordinates
tonga.poly.ortho <- poly(as.matrix(tonga.xy), degree = 3)
colnames(tonga.poly.ortho) <- 
  c("X", "X2", "X3", "Y", "XY", "X2Y", "Y2", "XY2", "Y3")
(tonga.trend.rda.ortho <- 
    rda(tonga.dc ~ ., 
        data = as.data.frame(tonga.poly.ortho)))
(R2adj.poly2 <- RsquareAdj(tonga.trend.rda.ortho)$adj.r.squared) #same as above

# PArsiomnious model 
#Forward selection  
# criterion
(tonga.trend.fwd <- 
    forward.sel(tonga.dc, tonga.poly.ortho, adjR2thresh = R2adj.poly2))

# New RDA using the 8 terms retained
(tonga.trend.rda2 <- rda(tonga.dc ~ ., 
                         data = as.data.frame(tonga.poly)[ ,tonga.trend.fwd[ ,2]]))

# Overall test and test of the canonical axes
anova(tonga.trend.rda2)
anova(tonga.trend.rda2, by = "axis")

# Plot of the 4 independent significant spatial structures (canonical axes) 
tonga.trend.fit <- 
  scores(tonga.trend.rda2, 
         choices = 1:4, 
         display = "lc", 
         scaling = 1)
dev.new(
  title = "tonga Trend Surface Analysis", 
  noRStudioGD = TRUE
)
s.value(tonga.xy, tonga.trend.fit, symbol = "circle")

# Distance-based Moran eigenvector maps (dbMEM) ===================
## dbMEM analysis of the reef fish tonga data

# Is there a linear trend in the tonga data?
anova(rda(tonga.dc, tonga.xy))
# Result: significant trend

# Computation of linearly detrended tonga data
tonga.dc.det <- resid(lm(as.matrix(tonga.dc) ~ ., data = tonga.xy)) #again 

## Step 1. Construct the matrix of dbMEM variables
tonga.dbmem.tmp <- dbmem(tonga.xy, silent = FALSE)
# Argument silent = FALSE allows the function to display 
# the truncation level.
(tonga.dbmem <- as.data.frame(tonga.dbmem.tmp))
RsquareAdj(rda(tonga.dc, tonga.dbmem)) #0.3443797
#we would expect more since only 12% is linear
#maybe look at negative dbMEM
#to see if neighbouring sites more different from each other than you would expect randomly.

# Truncation distance used above:
(thr <- give.thresh(dist(tonga.xy)))

# Display and count the eigenvalues
attributes(tonga.dbmem.tmp)$values
length(attributes(tonga.dbmem.tmp)$values) #this retains the 16 positive eigenvalues

## Step 2. Run the global dbMEM analysis on the *detrended*
##    Chord-transformed tonga data
(tonga.dbmem.rda <- rda(tonga.dc.det ~ ., tonga.dbmem))
# with tonga.dc.det <- resid(lm(as.matrix(tonga.dc) ~ ., data = tonga.xy))
anova(tonga.dbmem.rda) #significant

## Step 3. Since the R-square is significant, compute the adjusted
##    R2 and run a forward selection of the dbmem variables
(tonga.R2a <- RsquareAdj(tonga.dbmem.rda)$adj.r.squared) #0.2255962
(tonga.dbmem.fwd <- forward.sel(tonga.dc.det, as.matrix(tonga.dbmem), 
                                adjR2thresh = tonga.R2a))
(nb.sig.dbmem <- nrow(tonga.dbmem.fwd))    # Number of signif. dbMEM = 8
# Identity of the significant dbMEM in increasing order
(dbmem.sign <- sort(tonga.dbmem.fwd[ ,2]))
# Write the significant dbMEM to a new object
dbmem.red <- tonga.dbmem[ ,c(dbmem.sign)]

## Step 4. New dbMEM analysis with 8 significant dbMEM variables
##    Adjusted R-square after forward selection: R2adj = 0.2255962 --> 0.1924879 
#since this is a better model, shouldn't it have a higher R2Adj? 
0.1924879*var.res 
#explains 0.1694201 of total variation (not bad, but there is still a lot unexplained
#maybe check the negative or non-null dbMEMS)
(tonga.dbmem.rda2 <- rda(tonga.dc.det ~ ., data = dbmem.red))
(tonga.fwd.R2a <- RsquareAdj(tonga.dbmem.rda2)$adj.r.squared)
anova(tonga.dbmem.rda2) #sign
(axes.test <- anova(tonga.dbmem.rda2, by = "axis"))
# Number of significant axes
(nb.ax <- length(which(axes.test[ ,ncol(axes.test)] <=  0.05))) #not so important

## Step 5. Plot the significant canonical axes
tonga.rda2.axes <- 
  scores(tonga.dbmem.rda2, 
         choices = c(1:nb.ax), 
         display = "lc", 
         scaling = 1)
dev.new(
  title = "dbMEM analysis of tonga data", 
  width = 8, 
  height = 6, 
  noRStudioGD = TRUE
)
par(mfrow = c(1,nb.ax))
for(i in 1:nb.ax){
  sr.value(tonga.xy, tonga.rda2.axes[ ,i], 
           sub = paste("RDA",i), 
           csub = 2)
}

# Interpreting the spatial variation: regression of the significant
# canonical axes on the environmental variables, with Shapiro-Wilk 
# normality tests of residuals
tonga.rda2.axis1.env <- lm(tonga.rda2.axes[ ,1] ~ ., data = tonga.env)
shapiro.test(resid(tonga.rda2.axis1.env)) #residuals are normal
summary(tonga.rda2.axis1.env)
#market, 20m, village, land

tonga.rda2.axis2.env <- lm(tonga.rda2.axes[ ,2] ~ ., data = tonga.env)
shapiro.test(resid(tonga.rda2.axis2.env)) #residuals are normal
summary(tonga.rda2.axis2.env)

# Depending on the permutation-based p-value the third axis may 
# not be significant. In that case the 3 next lines of code will
# return error messages.
tonga.rda2.axis3.env <- lm(tonga.rda2.axes[ ,3] ~ ., data = tonga.env)
shapiro.test(resid(tonga.rda2.axis3.env))
summary(tonga.rda2.axis3.env)
#20, market, hard, lagoon, fp

# Scalogram of the variance explained by all dbMEM eigenfunctions, 
# computed with our homemade function scalog()
dev.new(
  title = "Scalogram",
  width = 10,
  height = 5,
  noRStudioGD = TRUE)
scalog(tonga.dbmem.rda)

# Maps of the 8 significant dbMEM variables with the homemade
# function sr.value()
dev.new(
  title = "8 dbMEM variables - Tongatapu", 
  width = 10, 
  height = 4,
  noRStudioGD = TRUE
)
par(mfrow = c(2, 4))
for(i in 1 : ncol(dbmem.red))
{
  sr.value(tonga.xy, 
           dbmem.red[ ,i], 
           #             sub = paste("dbMEM",i), 
           sub = paste("dbMEM",dbmem.sign[i]), 
           csub = 2, clegend=1.5, grid=FALSE)
}


# Maps with s.value()
dev.new(
  title = "8 dbMEM variables - tongas", 
  noRStudioGD = TRUE
)
par(mfrow = c(1,1))
s.value(tonga.xy, dbmem.red, method = "size",symbol = "circle")

## dbMEM analysis of the tonga data - broad scale
(tonga.dbmem.broad <- 
    rda(tonga.dc.det ~ ., data = tonga.dbmem[ ,c(1,3,4)]))
anova(tonga.dbmem.broad)
(axes.broad <- anova(tonga.dbmem.broad, by = "axis"))
# Number of significant axes = 1
(nb.ax.broad <- 
    length(which(axes.broad[ , ncol(axes.broad)] <=  0.05)))

# Plot of the significant canonical axes
tonga.dbmembroad.axes <- 
  scores(tonga.dbmem.broad, 
         choices = c(1,1), 
         display = "lc", 
         scaling = 1)
dev.new(
  title = "dbMEM analysis of tonga data - broad scale", 
  noRStudioGD = TRUE
)
par(mfrow = c(1, 2))
sr.value(tonga.xy, tonga.dbmembroad.axes[ ,1])
sr.value(tonga.xy, tonga.dbmembroad.axes[ ,2])

# Interpreting the broad-scaled spatial variation: regression of
# the two significant spatial canonical axes on the environmental
# variables
tonga.dbmembroad.ax1.env <- 
  lm(tonga.dbmembroad.axes[ ,1] ~ ., data = tonga.env)
summary(tonga.dbmembroad.ax1.env)
tonga.dbmembroad.ax2.env <- 
  lm(tonga.dbmembroad.axes[ ,2] ~ ., data = tonga.env)
summary(tonga.dbmembroad.ax2.env)


## dbMEM analysis of the tonga data - medium scale
(tonga.dbmem.med <- 
    rda(tonga.dc.det ~ ., data = tonga.dbmem[ ,c(5,7,9,11)]))
anova(tonga.dbmem.med)
(axes.med <- anova(tonga.dbmem.med, by = "axis"))
# Number of significant axes
(nb.ax.med <- length(which(axes.med[ ,ncol(axes.med)] <=  0.05)))

# Plot of the significant canonical axes
tonga.dbmemmed.axes <- 
  scores(tonga.dbmem.med, choices = c(1,2), 
         display = "lc", 
         scaling = 1)
dev.new(
  title = "dbMEM analysis of tonga data - medium scale", 
  noRStudioGD = TRUE
)
par(mfrow = c(1, 2))
sr.value(tonga.xy, tonga.dbmemmed.axes[ ,1])
sr.value(tonga.xy, tonga.dbmemmed.axes[ ,2])

# Interpreting the medium-scaled spatial variation: regression of
# the two significant spatial canonical axes on the environmental
# variables
tonga.dbmemmed.ax1.env <- 
  lm(tonga.dbmemmed.axes[ ,1] ~ ., data = tonga.env)
summary(tonga.dbmemmed.ax1.env)
tonga.dbmemmed.ax2.env <- 
  lm(tonga.dbmemmed.axes[ ,2] ~ ., data = tonga.env)
summary(tonga.dbmemmed.ax2.env)


## dbMEM analysis of the tonga data - fine scale
(tonga.dbmem.fine <- 
    rda(tonga.dc.det ~ ., data = as.data.frame(tonga.dbmem[ ,14])))
anova(tonga.dbmem.fine)
# Analysis stops here, since the RDA is not significant.

######################Let's look at negative dbMEMS ##################################
#not interesting
#tonga.dbmem.test2 <- dbmem(tonga.xy, silent = F, MEM.autocor=c("non-null"))
#(tonga.dbmem.null <- as.data.frame(tonga.dbmem.test2))
#RsquareAdj(rda(tonga.dc, tonga.dbmem.null))

tonga.dbmem.test <- dbmem(tonga.xy, silent = F, MEM.autocor=c("negative"))
(tonga.dbmem.neg <- as.data.frame(tonga.dbmem.test))
RsquareAdj(rda(tonga.dc, tonga.dbmem.neg))


(tonga.dbmem.neg.rda <- rda(tonga.dc.det ~ ., tonga.dbmem.neg))
(tonga.dbmem.neg.rda0 <- rda(tonga.dc.det ~ 1, tonga.dbmem.neg))
anova(tonga.dbmem.neg.rda) #not significant when using biomass
(tonga.neg.R2a <- RsquareAdj(tonga.dbmem.neg.rda)$adj.r.squared)
(tonga.dbmem.neg.fwd <- forward.sel(tonga.dc.det, as.matrix(tonga.dbmem.neg), alpha = 0.5)) 
#alpha needs to be above 0.2 but will still have significant anova if under 0.6
#even if the individual MEMS are not significant, they explain a significant part of the variation 
tonga.dbmem.neg.sel <- tonga.dbmem.neg[,tonga.dbmem.neg.fwd$order]
RsquareAdj(rda(tonga.dc.det, tonga.dbmem.neg.sel)) 
(nb.sig.dbmem.neg <- nrow(tonga.dbmem.neg.fwd))    # Number of signif. dbMEM 9 neg that explain something
# Identity of the significant dbMEM in increasing order
(dbmem.sign.neg <- sort(tonga.dbmem.neg.fwd[ ,2]))
# Write the significant dbMEM to a new object
dbmem.red.neg <- tonga.dbmem.neg[ ,c(dbmem.sign.neg)]
## No sign 
##    Adjusted R-square after forward selection:
(tonga.dbmem.neg.rda2 <- rda(tonga.dc.det ~ ., data = dbmem.red.neg))
(tonga.fwd.R2a.neg <- RsquareAdj(tonga.dbmem.neg.rda2)$adj.r.squared) #0.109 (0.04 with detrended)
anova(tonga.dbmem.neg.rda2) #signif.
(axes.test <- anova(tonga.dbmem.neg.rda2, by = "axis"))
# Number of significant axes
(nb.ax.neg <- length(which(axes.test[ ,ncol(axes.test)] <=  0.05)))#1

## Step 5. Plot the significant canonical axes
tonga.rda2.axes.neg <- 
  scores(tonga.dbmem.neg.rda2, 
         choices = c(1:nb.ax.neg), 
         display = "lc", 
         scaling = 1)
dev.new(
  title = "dbMEM analysis of tonga data", 
  width = 8, 
  height = 6, 
  noRStudioGD = TRUE
)
par(mfrow = c(1,nb.ax.neg))
for(i in 1:nb.ax.neg){
  sr.value(tonga.xy, tonga.rda2.axes.neg[ ,i], 
           sub = paste("RDA",i), 
           csub = 2)
}

## tonga - trend - environment - dbMEM variation partitioning
# 1. Test trend
tonga.XY.rda <- rda(tonga.dc, tonga.xy)
anova(tonga.XY.rda)
# 2. Test and forward selection of the environmental variables
# Forward selection of the environmental variables
tonga.env.rda <- rda(tonga.dc ~., tonga.env)
(tonga.env.R2a <- RsquareAdj(tonga.env.rda)$adj.r.squared)
tonga.env.fwd <- 
  forward.sel(tonga.dc, tonga.env,
              adjR2thresh = tonga.env.R2a, 
              nperm = 9999)
env.sign <- sort(tonga.env.fwd$order) #we had already found a good model in last section, so not surprising
env.red <- tonga.env[ ,c(env.sign)] #removed slope
colnames(env.red)

# 3. Test and forward selection of the dbMEM variables
# Run the global dbMEM analysis on the *detrended* tonga data
tonga.det.dbmem.rda <- rda(tonga.dc.det ~., tonga.dbmem)
anova(tonga.det.dbmem.rda) #sign
# Since the analysis is significant, compute the adjusted R2
# and run a forward selection of the dbMEM variables
(tonga.det.dbmem.R2a <- 
    RsquareAdj(tonga.det.dbmem.rda)$adj.r.squared)
(tonga.det.dbmem.fwd <- 
    forward.sel(tonga.dc.det, 
                as.matrix(tonga.dbmem), 
                adjR2thresh = tonga.det.dbmem.R2a)) #same as above
# Number of significant dbMEM
(nb.sig.dbmem <- nrow(tonga.det.dbmem.fwd))
# Identify the significant dbMEM sorted in increasing order
(dbmem.sign <- sort(tonga.det.dbmem.fwd$order))
# Write the significant dbMEM to a new object (reduced set)
dbmem.red <- tonga.dbmem[ ,c(dbmem.sign)]

# 4. Arbitrarily split the significant dbMEM into broad and 
#    fine scale
# Broad scale: dbMEM 1, 3, 4, 5, 6
dbmem.broad <- dbmem.red %>% dplyr::select(1, 3, 6, 7)
# Fine scale: dbMEM 9, 11, 14
dbmem.fine <- dbmem.red %>% dplyr::select(2, 5, 8)

## 5. tonga - environment - trend - dbMEM variation partitioning
(tonga.varpart <- 
    varpart(tonga.dc, env.red, tonga.xy, dbmem.broad, dbmem.fine))
dev.new(
  title = "tonga - environment - dbMEM variation partitioning", 
  width = 12, 
  height = 6, 
  noRStudioGD = TRUE
)
# Show the symbols of the fractions and plot their values
par(mfrow = c(1,2))
showvarparts(4, bg = c("red", "blue", "yellow", "green"))
plot(tonga.varpart, 
     digits = 2, 
     bg = c("red", "blue", "yellow", "green")
) 
# Tests of the unique fractions [a], [b], [c] and [d] --> sign
# Fraction [a], pure environmental
anova(
  rda(tonga.dc, env.red, cbind(tonga.xy, dbmem.broad, dbmem.fine))
)
# Fraction [b], pure trend --> not sign
anova(
  rda(tonga.dc, tonga.xy, cbind(env.red, dbmem.broad, dbmem.fine))
)
# Fraction [c], pure broad scale spatial --> not sign
anova(rda
      (tonga.dc, dbmem.broad, cbind(env.red, tonga.xy, dbmem.fine))
)
# Fraction [d], pure fine scale spatial --> not sign
anova(
  rda(tonga.dc, dbmem.fine, cbind(env.red, tonga.xy, dbmem.broad))
)

plot(varpart(tonga.dc, tonga.xy, dbmem.red.neg, dbmem.red, tonga.env))
plot.varpart(tonga.dc, tonga.xy, dbmem.red.neg, dbmem.red, tonga.env)
plot(varpart(tonga.dc, tonga.xy, dbmem.red.neg, tonga.env))
plot(varpart(tonga.dc, tonga.xy, dbmem.red, tonga.env))

(tonga.varpart2 <- 
    varpart(tonga.dc, env.red, tonga.xy, dbmem.red, dbmem.red.neg))
dev.new(
  title = "tonga - environment - dbMEM variation partitioning", 
  width = 12, 
  height = 6, 
  noRStudioGD = TRUE
)
# Show the symbols of the fractions and plot their values
par(mfrow = c(1,2))
showvarparts(4, bg = c("red", "blue", "yellow", "green"))
plot(tonga.varpart2, 
     digits = 2, 
     bg = c("red", "blue", "yellow", "green")
) 
# Tests of the unique fractions [a], [b], [c] and [d] --> sign
# Fraction [a], pure environmental
anova(
  rda(tonga.dc, env.red, cbind(tonga.xy, dbmem.red, dbmem.red.neg))
)
# Fraction [b], pure trend --> not sign
anova(
  rda(tonga.dc, tonga.xy, cbind(env.red, dbmem.red, dbmem.red.neg))
)
# Fraction [c], pure broad scale spatial -->  sign
anova(rda
      (tonga.dc, dbmem.red, cbind(env.red, tonga.xy, dbmem.red.neg))
)
# Fraction [d], pure red.neg scale spatial --> sign
anova(
  rda(tonga.dc, dbmem.red.neg, cbind(env.red, tonga.xy, dbmem.red))
)
tonga.varpart2 # has an adjusted R2 of 0.48379 ( 0.49506 if we use tonga.env and not env.red)
tonga.varpart #has an adjusted R2 of 0.42576
#0.51748  

#LAST TRY
(tonga.varpart3 <- 
    varpart(tonga.dc, e1.5.7, tonga.xy, dbmem.red, dbmem.red.neg))
dev.new(
  title = "tonga - environment - dbMEM variation partitioning", 
  width = 12, 
  height = 6, 
  noRStudioGD = TRUE
)
# Show the symbols of the fractions and plot their values
par(mfrow = c(1,2))
showvarparts(4, bg = c("red", "blue", "yellow", "green"))
plot(tonga.varpart3, 
     digits = 2, 
     bg = c("red", "blue", "yellow", "green")
) 
# Tests of the unique fractions [a], [b], [c] and [d] --> sign
# Fraction [a], pure environmental
anova(
  rda(tonga.dc, e1.5.7, cbind(tonga.xy, dbmem.red, dbmem.red.neg))
)
# Fraction [b], pure trend --> not sign
anova(
  rda(tonga.dc, tonga.xy, cbind(e1.5.7, dbmem.red, dbmem.red.neg))
)
# Fraction [c], pure broad scale spatial -->  sign
anova(rda
      (tonga.dc, dbmem.red, cbind(e1.5.7, tonga.xy, dbmem.red.neg))
)
# Fraction [d], pure red.neg scale spatial --> sign
anova(
  rda(tonga.dc, dbmem.red.neg, cbind(e1.5.7, tonga.xy, dbmem.red))
)

#########################################
# Detrend mite data on Y coordinate
tonga.dc.det2  <- resid(lm(as.matrix(tonga.dc) ~ tonga.xy[ ,2]))
# Detrend environmental data on Y coordinate
env.det2 <- resid(lm(as.matrix(tonga.env) ~ tonga.xy[ ,2]))
# RDA and MSO
det.envdet.rda <- rda(tonga.dc.det2 ~., env.det2)
(miteenvdet.rda.mso <-
    mso(det.envdet.rda,
        tonga.xy,
        grain = dmin,
        perm = 999))
msoplot(det.envdet.rda.mso, alpha = 0.05/7, ylim = c(0, 0.006))


#All these analyses could be performed on presence-absence data. What results would you expect by doing this ? 
#Will patterns be more strongly expressed or not ? To transform  community data to presence absence you can use:
tonga.pa <- decostand(tonga.a, method="pa")


# Replacement, richness and nestedness indices of the fish data ===

# Jaccard-based Podani indices (presence-absence data)
fish.pod.j <- beta.div.comp(tonga.d, coef = "J", quant = FALSE)
# What is in the output object?
summary(fish.pod.j)
# Display summary statistics:
fish.pod.j$part
# Extraction of the richness difference matrix
fish.rich <- as.matrix(fish.pod.j$rich)
# Plot of the richness difference with retonga.dct to site 30
fish.rich.60 <- fish.rich[59, ][-59]
site.names <- seq(1, 59)
dev.new(
  title = "Tonga fish data: richness difference with retonga.dct to site 60 - Jaccard",
  width = 12, 
  height = 5,
  noRStudioGD = TRUE
)
plot(site.names, 
     fish.rich.60, 
     type = "n", 
     xaxp = c(1, 59, 58 ),
     main = "Tonga fish data: richness difference with retonga.dct to site 60", 
     xlab = "Site number", 
     ylab = "Richness difference"
)
lines(site.names, fish.rich.60, pch = 24, col = "red")
points(
  site.names, 
  fish.rich.60, 
  pch = 24, 
  cex = 1.5, 
  col = "white", 
  bg = "red"
)


# Extraction of the replacement matrix
fish.repl <- as.matrix(fish.pod.j$repl)
# Extraction of the Jaccard dissimilarity Dj matrix
fish.jac <- as.matrix(fish.pod.j$D)

# Plot of the Jaccard, replacement and richness difference indices 
# between nearest neighbours
# First, extract the subdiagonals of the square dissimilarity 
# matrices
fish.repl.neigh <- diag(fish.repl[-1, ]) # Replacement
fish.rich.neigh <- diag(fish.rich[-1, ]) # Richness difference
fish.jac.neigh <- diag(fish.jac[-1, ]) # Jaccard Dj index

dev.new(
  title = "Replacement - Richness difference - Jaccard - nearest neighbours",
  width = 15,
  height = 6,
  noRStudioGD = TRUE
)
absc <- c(2:8, 9:60) # Abscissa
label.pairs <- c("1-2", "2-3", "3-4", "4-5", "5-6", "6-7", "7-8", 
                 "7-9", "9-10", "10-11", "11-12", "12-13", "13-14", "14-15", 
                 "15-16", "16-17", "17-18", "18-19", "19-20", "20-21", "21-22", 
                 "22-23", "23-24", "24-25", "25-26", "26-27", "27-28", "28-29", 
                 "29-30", "30-31", "31-32", "32-33", "33-34", "34-35", "35-36",
                 "36-37","37-38","38-39","39-40","40-41","41-42","42-43","43-44",
                 "44-45","45-46","46-47","47-48","48-49","49-50","50-51","51-52","52-53",
                 "53-54","54-55","55-56","56-57","57-58","58-59","59-60")
plot(
  absc, 
  fish.rich.neigh+fish.rich.neigh, 
  type = "n", 
  xaxt = "n",
  main = "Replacement - Richness difference - Jaccard - nearest neighbours",  
  xlab = "Site pairs", 
  ylab = "Podani's indices"
)
axis(side = 1, 2:60, labels = label.pairs, las = 1, cex.axis = 0.9)
lines(absc, fish.jac.neigh, col = "black")
points(
  absc, 
  fish.jac.neigh, 
  pch = 21, 
  cex = 2, 
  col = "black", 
  bg = "black"
)
lines(absc, fish.repl.neigh, col = "blue")
points(
  absc, 
  fish.repl.neigh, 
  pch = 22, 
  cex = 2, 
  col = "white", 
  bg = "blue"
)
lines(absc, fish.rich.neigh, col = "red")
points(
  absc, 
  fish.rich.neigh, 
  pch = 24, 
  cex = 2, 
  col = "white", 
  bg = "red"
)
legend(
  "topleft", 
  c("Jaccard D", "Replacement", "Richness difference"), 
  pch = c(16, 15, 17), 
  col = c("black", "blue", "red"), 
  ncol=3,
)

# Triangular plots
# Jaccard
fish.pod.J <- beta.div.comp(tonga.d, coef = "J", quant = FALSE)
# Sorensen
fish.pod.S <- beta.div.comp(tonga.d, coef = "S", quant = FALSE)
# Ruzicka
fish.pod.qJ <- beta.div.comp(tonga.d, coef = "J", quant = TRUE)
# Percentage difference
fish.pod.qS <- beta.div.comp(tonga.d, coef = "S", quant = TRUE)
# Data frames for the triangular plots
fish.pod.J.3 <- cbind((1 - fish.pod.J$D),
                      fish.pod.J$repl,
                      fish.pod.J$rich)
colnames(fish.pod.J.3) <- c("Similarity", "Repl", "RichDiff")
fish.pod.S.3 <- cbind((1 - fish.pod.S$D),
                      fish.pod.S$repl,
                      fish.pod.S$rich)
colnames(fish.pod.S.3) <- c("Similarity", "Repl", "RichDiff")
fish.pod.qJ.3 <- cbind((1 - fish.pod.qJ$D),
                       fish.pod.qJ$repl,
                       fish.pod.qJ$rich)
colnames(fish.pod.qJ.3) <- c("Similarity", "Repl", "AbDiff")
fish.pod.qS.3 <- cbind((1 - fish.pod.qS$D),
                       fish.pod.qS$repl,
                       fish.pod.qS$rich)
colnames(fish.pod.qS.3) <- c("Similarity", "Repl", "AbDiff")

dev.new(
  title = "Similarity - Replacement - Richness difference - Triangular plots",
  width = 10,
  height = 10,
  noRStudioGD = TRUE
)
par(mfrow = c(2, 2))
triangle.plot(
  as.data.frame(fish.pod.J.3[, c(3, 1, 2)]),
  show = FALSE,
  labeltriangle = FALSE,
  addmean = TRUE
)
text(-0.45, 0.5, "RichDiff", cex = 1.5)
text(0.4, 0.5, "Repl", cex = 1.5)
text(0, -0.6, "Jaccard similarity", cex = 1.5)
triangle.plot(
  as.data.frame(fish.pod.S.3[, c(3, 1, 2)]),
  show = FALSE,
  labeltriangle = FALSE,
  addmean = TRUE
)
text(-0.45, 0.5, "RichDiff", cex = 1.5)
text(0.4, 0.5, "Repl", cex = 1.5)
text(0, -0.6, "Sørensen similarity", cex = 1.5)

triangle.plot(
  as.data.frame(fish.pod.qJ.3[, c(3, 1, 2)]),
  show = FALSE,
  labeltriangle = FALSE,
  addmean = TRUE
)
text(-0.45, 0.5, "AbDiff", cex = 1.5)
text(0.4, 0.5, "Repl", cex = 1.5)
text(0, -0.6, "S = 1 – Ružička D", cex = 1.5)
triangle.plot(
  as.data.frame(fish.pod.qS.3[, c(3, 1, 2)]),
  show = FALSE,
  labeltriangle = FALSE,
  addmean = TRUE
)
text(-0.45, 0.5, "AbDiff", cex = 1.5)
text(0.4, 0.5, "Repl", cex = 1.5)
text(0, -0.6, "S = 1 – Percentage difference", cex = 1.5)
# Display values of the mean points in the triangular plots
colMeans(fish.pod.J.3[, c(3, 1, 2)])
colMeans(fish.pod.S.3[, c(3, 1, 2)])
colMeans(fish.pod.qJ.3[, c(3, 1, 2)])
colMeans(fish.pod.qS.3[, c(3, 1, 2)])


# Explaining replacement and richness difference
# by means of db-RDA

# Replacement
repl.dbrda <- dbrda(fish.repl ~ ., data = tonga.env, add = "cailliez")
anova(repl.dbrda)
RsquareAdj(repl.dbrda)

# Richness difference
rich.dbrda <- dbrda(fish.rich ~ ., data = tonga.env, add = "cailliez")
anova(rich.dbrda)
RsquareAdj(rich.dbrda)

dev.new(title = "RDA Richness difference explained by tonga.environment",
        noRStudioGD = TRUE)
plot(
  rich.dbrda,
  scaling = 1,
  display = c("lc", "cn"),
  main = "Richness difference explained by tonga.environmental variables"
)
#Compare with 
triplot.rda(step.e1.5.7)

# Computation using beta.div {adespatial} on 
tonga.beta <- beta.div(tonga.d, method = "chord", nperm = 9999)
summary(tonga.beta)
tonga.beta$beta  # SSTotal and BDTotal
# Which species have a SCBD larger than the mean SCBD?
tonga.beta$SCBD[tonga.beta$SCBD >= mean(tonga.beta$SCBD)]
# LCBD values
tonga.beta$LCBD
# p-values
tonga.beta$p.LCBD
# Holm correction
p.adjust(tonga.beta$p.LCBD, "holm")
# Sites with significant Holm-corrected LCBD value
row.names(tonga[which(p.adjust(tonga.beta$p.LCBD, "holm") <= 0.05),])

# Plot the LCBD values on the river map
dev.new(title = "LCBD of the 60 sites", noRStudioGD = TRUE)
plot(tonga.xy, 
     asp = 1, 
     cex.axis = 0.8, 
     pch = 21, 
     col = "white", 
     bg = "brown", 
     cex = tonga.beta$LCBD * 100, 
     main = "LCBD values", 
     xlab = "x coordinate (km)", 
     ylab = "y coordinate (km)"
)
lines(tonga.xy, col = "light blue")
text(85, 11, "***", cex = 1.2, col = "red")
text(80, 92, "***", cex = 1.2, col = "red")

save(tongu_data, envtable, tonga, tonga.gps, tonga.env, file = "Tonga.RData")


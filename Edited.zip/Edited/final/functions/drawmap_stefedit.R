# Map of the Doubs river (see Chapter 2)
# License: GPL-2
# Author:  Francois Gillet

#EDIT: palette()
#library(unikn)
#n <- 10
#h1 <- hcl.colors(n, palette = "Dynamic")
#palette(h1)

drawmap <-
  function(xy = spa, clusters, main = "Clusters along the Doubs river", tcol = "white" ) {

    # Draw the Doubs river
    plot(
      xy,
      asp = 1,
      type = "n",
      main = main,
      xlab = "x coordinate (km)",
      ylab = "y coordinate (km)"
    )
    lines(xy, col = "light blue")
    text(65, 20, "Upstream", cex = 1.2)
    text(15, 32, "Downstream", cex = 1.2)
    
    # Add the clusters
    k <- length(levels(factor(clusters)))
    for (i in 1:k)
    {
      points(
        xy[clusters == i, 1],
        xy[clusters == i, 2],
  #      pch = i + 12,
      pch = 19, #changed
        cex = 3,
        col = i + 1,
        bg = i + 1
      )
    }
    text(xy,
         row.names(xy),
         cex = 0.5,
         col = "black", #changed
         font = 2)
    legend(
      "bottomleft", #changed
      paste("Cluster", 1:k),
 #     pch = (1:k) + 1,
     pch = 19, #changed
      col = 2:(k + 1),
      pt.bg = 2:(k + 1),
      pt.cex = 2,
      bty = "n"
    )
    
  }
